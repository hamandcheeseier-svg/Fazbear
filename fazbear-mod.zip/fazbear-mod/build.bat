@echo off
echo Building Fazbear Animatronics (needs Java 17)...
call gradlew.bat build
echo.
echo Done! Your jar is in build\libs\  (use the one WITHOUT "-sources" in the name)
pause
