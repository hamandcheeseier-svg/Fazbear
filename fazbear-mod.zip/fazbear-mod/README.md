# Fazbear Animatronics 3.0 (Minecraft Forge 1.20.1)

Fan-made, non-commercial mod. Build a pizzeria, craft suits for **42 characters** from every mainline game,
build endoskeletons from **3 endo types**, mix and match every part, wake them up, and survive the night shift.

---------------------------------------------------------------------------
## HOW TO TURN THIS INTO A .JAR

You need **Java 17** (https://adoptium.net -> Temurin 17). Nothing else - the Gradle wrapper is included.

### Option A - on your PC
1. Unzip somewhere with a short path (e.g. `C:\fazbear-mod`).
2. **Windows:** double-click `build.bat`.  **Mac/Linux:** run `./build.sh`.
3. First run downloads Minecraft + Forge (5-15 min, needs internet).
4. Your mod is `build/libs/fazbear-2.0.0.jar` (ignore files with "sources" in the name).
5. Put it in your Minecraft `mods` folder (Forge 1.20.1, 47.2.0 or newer).

### Option B - let GitHub build it (no Java needed)
1. Create a free GitHub repo, upload this whole folder (keep `.github`).
2. Open the **Actions** tab -> "Build mod jar" runs automatically (or "Run workflow").
3. When it is green, open the run and download the **fazbear-jar** artifact.

### If the build fails
Send me the red error text. This was written without being able to compile it, so a small fix may be needed.
---------------------------------------------------------------------------

## Characters (42)
- **FNaF 1** (5): Freddy, Bonnie, Chica, Foxy, Golden Freddy
- **FNaF 2** (11): Toy Freddy, Toy Bonnie, Toy Chica, Mangle, Balloon Boy, The Puppet, Withered Freddy, Withered Bonnie, Withered Chica, Withered Foxy, Withered Golden Freddy
- **FNaF 3** (2): Springtrap, Spring Bonnie
- **FNaF 4** (8): Nightmare Freddy, Nightmare Bonnie, Nightmare Chica, Nightmare Foxy, Nightmare Fredbear, Nightmare, Plushtrap, Fredbear
- **Sister Location** (5): Circus Baby, Ballora, Funtime Freddy, Funtime Foxy, Ennard
- **Pizzeria Simulator** (4): Scrap Baby, Molten Freddy, Lefty, Scraptrap
- **Security Breach** (7): Glamrock Freddy, Glamrock Chica, Roxanne Wolf, Montgomery Gator, Sunrise, Moondrop, DJ Music Man

Every character has 4 suit pieces (Head, Torso, Arms, Legs), a Full Suit and a Plushie. All pieces are interchangeable.
Creative tabs: **Fazbear Animatronics** (blocks, tools, endo parts) and **Fazbear Suits & Plushies**.

## Endo types
**Endo 01** (classic), **Endo 02** (slim, faster, a bit fragile), **Yenndo** (heavy, tough, hits harder, slower).
Each has its own Leg / Torso / Arm / Head item and its own look. Mix them on one stand, any order, any type per part.

## Building an animatronic
1. **Endo Stand** -> right-click with parts in order: Leg, Leg, Torso, Arm, Arm, Head (any endo type for each).
2. Fit **suit pieces** from any characters into the Head / Torso / Arms / Legs slots (needs the matching endo part
   underneath). Right-click with another piece to swap. 4 matching pieces craft a Full Suit.
3. Empty hand + sneak removes the last thing (suit first, then endo). Breaking the stand drops everything.
4. **Redstone** on a fully dressed stand plays a tune (head = lead instrument, arms = harmony, legs = rhythm).

## Waking them up
- **Faz Key** on a finished stand -> a walking animatronic (walk cycle, head tracking).
- **Service Wrench** on it: toggle **SHOW** (friendly, plays music) / **NIGHT** (hunts at night or in a power outage,
  freezes while anyone looks at it, red eyes). Sneak + wrench = dock back into a stand.
- **Stats come from the parts:** legs set speed, arms set damage, torso (and a bit of head) set health. Bare endo
  parts use their endo type's stats. Withered characters hit harder but are fragile; Nightmares and Fredbears are tanks.
- **Abilities:** Foxy-style legs (Foxy, Withered/Nightmare/Funtime Foxy, Mangle, Plushtrap, Roxanne Wolf) **sprint**
  when nobody is looking. Molten Freddy arms **burn**. Circus Baby, Ennard and DJ Music Man arms **shock**.
- Mix a Foxy legs piece onto a Nightmare Fredbear body for a very bad time.

## Night shift
- **Power Core:** holds the night's power (3000 units = 7 minutes at 1/s). Right-click: show %, redstone = +30,
  redstone block = +300. Comparators read it. When it hits zero: **POWER OUT** - every animatronic within 48 blocks
  hunts you for 30 seconds regardless of Music Boxes.
- **Security Door:** blast door that blocks animatronics. Needs a Power Core within 32 blocks and drains 1/s while closed.
- **Office Light:** ceiling light panel; drains 1/s while lit if a Power Core is near, free otherwise.
- **Light Switch + Service Wrench linking:**
  1. Right-click the **switch** with the wrench -> the wrench glows (switch selected).
  2. Right-click each **Office Light** or **Security Door** -> linked (click again to unlink).
  3. Flip the switch: lights turn on/off, doors close/open. Up to 24 links per switch, within 48 blocks.
  4. Sneak + wrench on the switch clears its links. Sneak + wrench on air deselects.
- **Flashlight:** point at an animatronic to stun it for 5s (120 uses; repair with redstone on an anvil).
- **Music Box:** wind it for 45s of lullaby that keeps animatronics within 32 blocks calm; when it runs down they are enraged.
- **Security Monitor:** right-click to list animatronics within 48 blocks (who, distance, direction, mode) and the power %.
- **Pirate Cove Curtain:** right-click to draw open/closed.

## Pizzeria
- **Arcade Cabinet** (jingle + chance of a Faz Token), **Prize Counter** (5 tokens -> plushie / pizza / flashlight / wrench /
  suit piece), **Party Table**, Checkered Tile, Party Wall, Show Stage, **Pizza**.
- **Pizzeria Blueprint:** right-click the ground to build everything: dining room with arcade row, prize counter, party
  tables and ceiling lights on a wall switch; show stage with 3 stands, 5 plushies and a music box; **Pirate Cove** with a
  sleeping, fully assembled Foxy; **Parts & Service** room (right) with 7 chests holding EVERY suit piece, a chest of all
  endo parts, and 2 practice stands; **Security Office** (left) with monitor, Power Core, two doors wired to a switch,
  an office lamp on its own switch, and chests with flashlights, keys, redstone, tokens, lights, switches and doors.
- 10 advancements.

## Recipes (recipe book shows all of them)
| Item | Recipe |
|---|---|
| Endo Stand | ` I ` / `III` / `SSS` (iron ingot, stone) |
| Endo Leg / Arm | `M ` / `P ` / `MM` and `MM` / `P ` / `M ` (M = main material, P = piston) |
| Endo Torso | 8 M around a redstone block |
| Endo Head | 8 M around a redstone lamp |
| Main material | Endo 01 = iron ingot, Endo 02 = copper ingot, Yenndo = raw iron |
| Suit Head | `WWW` / `WLW` |
| Suit Torso | `WLW` / `WWW` / `WWW` |
| Suit Arms | `WWL` / `WWL` |
| Suit Legs | `WLW` / `W W` / `W W` |
| Full Suit | the 4 matching pieces (shapeless) |
| Plushie | matching suit head + wool + string |
| Faz Key | `GG` / `GI` / ` I` (gold ingot, iron ingot) |
| Flashlight | glowstone dust / redstone / iron ingot (vertical) |
| Music Box | `GGG` / `PNP` / `PPP` (gold ingot, note block, dark oak planks) |
| Power Core | iron ingots around a redstone block |
| Security Door (x2) | 2x3 iron ingots |
| Office Light (x2) | `III` / `ILI` (iron ingot, redstone lamp) |
| Light Switch | ` L ` / `IRI` (lever, iron ingot, redstone) |
| Security Monitor | `III` / `IGI` / ` R ` |
| Arcade Cabinet | `BBB` / `BGB` / `BRB` (blue concrete, glass pane, redstone) |
| Prize Counter | `QQQ` / `PPP` / `PPP` (quartz, dark oak planks) |
| Party Table | `WWW` / ` F ` |
| Pirate Cove Curtain (x3) | 2x3 purple wool |
| Faz Token | 3 gold nuggets |
| Pizza (x2) | 2 bread + cooked porkchop + beetroot |
| Service Wrench | `I I` / ` I ` / ` S ` |
| Pizzeria Blueprint | 8 paper around a gold ingot |

**Suit piece colours (W = wool, L = binder):** every character has a unique wool + binder pair so recipes never clash.
Freddy = brown wool + leather, Bonnie = purple + leather, Chica = yellow + leather, Foxy = red + leather,
Golden Freddy = orange wool + gold ingot; the rest use their theme colour with iron ingot, gold ingot, copper ingot,
amethyst shard, lapis, redstone, glowstone dust, quartz or string. Look any piece up in the recipe book.


## Model accuracy (and its limits)
Every character is built from textured boxes using only vanilla block textures, so they are blocky interpretations,
not exact replicas. They were checked by rendering each one from the box data and fixing what looked wrong. Signature
features included: top hats and bow ties (Freddy family), tall ears (Bonnie family, Springtrap), guitars (Bonnie, Toy Bonnie),
cupcakes and bibs (Chica family), hooks, eyepatches and open jaws (Foxy family), dark eye sockets (Golden Freddy,
Withered/Springtrap/Nightmare line), exposed endo faces, hands and ribs (Withered/Springtrap/Scraptrap), maws and big claws
(Nightmares), striped shirt, cap and balloon (Balloon Boy), mask and long thin limbs (Puppet), pigtails and dress
(Circus Baby), tiered tutu (Ballora), crest and star shades (Roxanne Wolf), ray crown and crescent horns (Sun / Moon).

Preview any change before building the jar:
`python3 preview.py` writes contact sheets to `/tmp/prev/` (chars_1.png ... and endos.png). Edit `characters_spec.py`
(colours are the 4 texture names after the game name; features are the tuples passed to `C(...)`), then run
`python3 gen_assets.py` to rebuild the data and assets.

## Editing
`characters_spec.py` defines every character and endo type (shapes, colours, stats, abilities, instruments).
`python3 gen_assets.py` regenerates GameData.java and every model, texture, recipe, advancement and lang entry
(needs Python + Pillow). Add a character by adding one `C(...)` line.
