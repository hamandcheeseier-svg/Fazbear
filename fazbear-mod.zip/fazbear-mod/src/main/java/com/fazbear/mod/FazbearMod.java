package com.fazbear.mod;

import com.fazbear.mod.registry.ModBlockEntities;
import com.fazbear.mod.registry.ModBlocks;
import com.fazbear.mod.registry.ModEntities;
import com.fazbear.mod.registry.ModItems;
import com.fazbear.mod.registry.ModTabs;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(FazbearMod.MODID)
public class FazbearMod {
    public static final String MODID = "fazbear";

    public FazbearMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(bus);
        ModBlockEntities.BLOCK_ENTITIES.register(bus);
        ModEntities.ENTITIES.register(bus);
        ModItems.ITEMS.register(bus);
        ModTabs.TABS.register(bus);
    }
}
