package com.fazbear.mod.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/** A thin wall-like plate that can be open (just the side posts remain) or closed. Faces along its thin axis. */
public class PlateBlock extends FacingBlock {
    public static final BooleanProperty OPEN = BlockStateProperties.OPEN;

    private final VoxelShape plateZ, plateX, postsZ, postsX;

    public PlateBlock(Properties props, int thickness, int post) {
        super(props, Shapes.block());
        int lo = 8 - thickness / 2, hi = 8 + thickness / 2;
        plateZ = Block.box(0, 0, lo, 16, 16, hi);
        plateX = Block.box(lo, 0, 0, hi, 16, 16);
        postsZ = Shapes.or(Block.box(0, 0, lo, post, 16, hi), Block.box(16 - post, 0, lo, 16, 16, hi));
        postsX = Shapes.or(Block.box(lo, 0, 0, hi, 16, post), Block.box(lo, 0, 16 - post, hi, 16, 16));
        registerDefaultState(defaultBlockState().setValue(OPEN, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        super.createBlockStateDefinition(builder);
        builder.add(OPEN);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        boolean z = state.getValue(FACING).getAxis() == Direction.Axis.Z;
        boolean open = state.getValue(OPEN);
        return z ? (open ? postsZ : plateZ) : (open ? postsX : plateX);
    }

    @Override
    public BlockState getStateForPlacement(net.minecraft.world.item.context.BlockPlaceContext ctx) {
        return defaultBlockState().setValue(FACING, ctx.getHorizontalDirection());
    }
}
