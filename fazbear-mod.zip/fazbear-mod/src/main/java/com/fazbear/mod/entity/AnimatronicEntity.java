package com.fazbear.mod.entity;

import com.fazbear.mod.Performance;
import com.fazbear.mod.Suits;
import com.fazbear.mod.block.EndoStandBlock;
import com.fazbear.mod.block.EndoStandBlockEntity;
import com.fazbear.mod.data.CharacterDef;
import com.fazbear.mod.data.Characters;
import com.fazbear.mod.data.EndoTypeDef;
import com.fazbear.mod.data.EndoTypes;
import com.fazbear.mod.item.ServiceWrenchItem;
import com.fazbear.mod.registry.ModBlocks;
import com.fazbear.mod.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.phys.Vec3;

/**
 * A walking animatronic made from a woken-up Endo Stand.
 *  SHOW mode : friendly, wanders and plays its tune when a player is near.
 *  NIGHT mode: at night (or during a power outage) it hunts players, but freezes while anyone is looking at it.
 * Stats and abilities come from the parts it is made of:
 *  legs  -> speed (and SPRINT for Foxy-style legs),   arms -> damage (and BURN / SHOCK),
 *  torso -> health,   head -> a little health.   Bare endo parts use their endo type's stats.
 * Flashlight stuns, a wound Music Box pacifies, a Power Core running dry enrages. Wrench toggles mode / docks.
 */
public class AnimatronicEntity extends PathfinderMob {
    public static final int MODE_SHOW = 0;
    public static final int MODE_NIGHT = 1;

    private static final EntityDataAccessor<Integer> SUIT_CODE =
            SynchedEntityData.defineId(AnimatronicEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> ENDO_CODE =
            SynchedEntityData.defineId(AnimatronicEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> MODE =
            SynchedEntityData.defineId(AnimatronicEntity.class, EntityDataSerializers.INT);

    private int stunTicks = 0;
    private long pacifyUntil = 0;
    private long powerOutUntil = 0;
    private boolean frozen = false;
    private int musicStep = 0;

    public AnimatronicEntity(EntityType<? extends AnimatronicEntity> type, Level level) {
        super(type, level);
        setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 40.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.27D)
                .add(Attributes.ATTACK_DAMAGE, 6.0D)
                .add(Attributes.FOLLOW_RANGE, 32.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.6D);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.15D, true));
        goalSelector.addGoal(2, new WaterAvoidingRandomStrollGoal(this, 0.6D));
        goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 8.0F));
        goalSelector.addGoal(4, new RandomLookAroundGoal(this));
        targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, 10, true, false, this::canHunt));
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(SUIT_CODE, 0);
        entityData.define(ENDO_CODE, 0);
        entityData.define(MODE, MODE_SHOW);
    }

    // ------------------------------------------------------------------ data

    /** slot 0 head, 1 torso, 2 arms, 3 legs; value 0..63 (character id) */
    public int getSuit(int slot) {
        return (entityData.get(SUIT_CODE) >> (6 * slot)) & 63;
    }

    public void setSuit(int[] suit) {
        int code = 0;
        for (int i = 0; i < 4; i++) code |= (suit[i] & 63) << (6 * i);
        entityData.set(SUIT_CODE, code);
        refreshStats();
    }

    public int[] suitArray() {
        return new int[]{getSuit(0), getSuit(1), getSuit(2), getSuit(3)};
    }

    /** part 0..5 (legL, legR, torso, armL, armR, head); value 0..7 (endo type) */
    public int getEndo(int part) {
        return (entityData.get(ENDO_CODE) >> (3 * part)) & 7;
    }

    public void setEndo(int[] endo) {
        int code = 0;
        for (int i = 0; i < 6; i++) code |= (endo[i] & 7) << (3 * i);
        entityData.set(ENDO_CODE, code);
        refreshStats();
    }

    public int[] endoArray() {
        int[] a = new int[6];
        for (int i = 0; i < 6; i++) a[i] = getEndo(i);
        return a;
    }

    public int getMode() { return entityData.get(MODE); }
    public void setMode(int mode) { entityData.set(MODE, mode); }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("SuitCode", entityData.get(SUIT_CODE));
        tag.putInt("EndoCode", entityData.get(ENDO_CODE));
        tag.putInt("Mode", getMode());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        entityData.set(SUIT_CODE, tag.getInt("SuitCode"));
        entityData.set(ENDO_CODE, tag.contains("EndoCode") ? tag.getInt("EndoCode") : 0x9249); // all Endo 01
        entityData.set(MODE, tag.getInt("Mode"));
        refreshStats();
    }

    // ------------------------------------------------------------------ stats from parts

    private float speedModOf(int slotCharacter, int endoPart) {
        CharacterDef c = Characters.get(slotCharacter);
        if (c != null) return c.speedMod;
        EndoTypeDef t = EndoTypes.get(getEndo(endoPart));
        return t == null ? 0f : t.speedMod;
    }

    private float damageModOf(int slotCharacter, int endoPart) {
        CharacterDef c = Characters.get(slotCharacter);
        if (c != null) return c.damageMod;
        EndoTypeDef t = EndoTypes.get(getEndo(endoPart));
        return t == null ? 0f : t.damageMod;
    }

    private float healthModOf(int slotCharacter, int endoPart) {
        CharacterDef c = Characters.get(slotCharacter);
        if (c != null) return c.healthMod;
        EndoTypeDef t = EndoTypes.get(getEndo(endoPart));
        return t == null ? 0f : t.healthMod;
    }

    private void refreshStats() {
        double speed = 0.27D * (1.0D + speedModOf(getSuit(Suits.LEGS), 0));
        double damage = 6.0D + damageModOf(getSuit(Suits.ARMS), 3);
        double health = 40.0D + healthModOf(getSuit(Suits.TORSO), 2) + 0.5D * healthModOf(getSuit(Suits.HEAD), 5);
        AttributeInstance a = getAttribute(Attributes.MOVEMENT_SPEED);
        if (a != null) a.setBaseValue(Math.max(0.1D, speed));
        a = getAttribute(Attributes.ATTACK_DAMAGE);
        if (a != null) a.setBaseValue(Math.max(1.0D, damage));
        a = getAttribute(Attributes.MAX_HEALTH);
        if (a != null) a.setBaseValue(Math.max(10.0D, health));
        if (getHealth() > getMaxHealth()) setHealth(getMaxHealth());
    }

    private int legAbility() {
        CharacterDef c = Characters.get(getSuit(Suits.LEGS));
        return c == null ? 0 : c.ability;
    }

    private int armAbility() {
        CharacterDef c = Characters.get(getSuit(Suits.ARMS));
        return c == null ? 0 : c.ability;
    }

    // ------------------------------------------------------------------ status effects from the player's tools

    public void stun(int ticks) { stunTicks = Math.max(stunTicks, ticks); }
    public boolean isStunned() { return stunTicks > 0; }

    public void pacify(int ticks) { pacifyUntil = Math.max(pacifyUntil, level().getGameTime() + ticks); }
    public boolean isPacified() { return level().getGameTime() < pacifyUntil; }

    /** Power Core ran dry: hunt regardless of the time of day, and ignore music boxes. */
    public void powerOut(int ticks) {
        powerOutUntil = Math.max(powerOutUntil, level().getGameTime() + ticks);
        pacifyUntil = 0;
        enrage(ticks);
    }

    public boolean isPowerOut() { return level().getGameTime() < powerOutUntil; }

    public void enrage(int ticks) {
        addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, ticks, 1));
        addEffect(new MobEffectInstance(MobEffects.GLOWING, ticks));
    }

    private boolean canHunt(LivingEntity target) {
        return getMode() == MODE_NIGHT && !isStunned() && (!isPacified() || isPowerOut())
                && (level().isNight() || isPowerOut());
    }

    private boolean isWatched() {
        for (Player p : level().getEntitiesOfClass(Player.class, getBoundingBox().inflate(40.0D))) {
            if (p.isSpectator() || p.isCreative()) continue;
            Vec3 to = getEyePosition().subtract(p.getEyePosition());
            double dist = to.length();
            if (dist < 0.01D) return true;
            if (p.getViewVector(1.0F).dot(to.scale(1.0D / dist)) > 0.55D && p.hasLineOfSight(this)) return true;
        }
        return false;
    }

    // ------------------------------------------------------------------ ticking

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        frozen = false;

        if (stunTicks > 0) {
            stunTicks--;
            frozen = true;
            if (getTarget() != null) setTarget(null);
            return;
        }
        if (isPacified() && !isPowerOut() && getTarget() != null) setTarget(null);

        if (getMode() == MODE_NIGHT) {
            if (getTarget() != null) {
                if (isWatched()) {
                    frozen = true;
                } else if (legAbility() == CharacterDef.ABILITY_SPRINT) {
                    // Foxy-style legs: bolt when nobody is looking
                    addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 10, 3, false, false));
                }
            }
        } else if (tickCount % 6 == 0) {
            int[] suit = suitArray();
            if (suit[0] > 0 && suit[1] > 0 && suit[2] > 0 && suit[3] > 0
                    && level().getNearestPlayer(this, 9.0D) != null) {
                Performance.step(level(), getX(), getY(), getZ(), suit, musicStep++);
            }
        }
    }

    @Override
    public void travel(Vec3 travelVector) {
        if (frozen) {
            setDeltaMovement(0.0D, getDeltaMovement().y, 0.0D);
            super.travel(Vec3.ZERO);
            return;
        }
        super.travel(travelVector);
    }

    // ------------------------------------------------------------------ combat

    @Override
    public boolean doHurtTarget(Entity target) {
        if (frozen || isStunned()) return false;
        boolean hit = super.doHurtTarget(target);
        if (!hit) return false;
        int ability = armAbility();
        if (ability == CharacterDef.ABILITY_BURN) {
            target.setSecondsOnFire(5);
        } else if (ability == CharacterDef.ABILITY_SHOCK && target instanceof LivingEntity le) {
            le.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 1));
            le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 2));
            playSound(SoundEvents.TRIDENT_THUNDER, 1.0F, 1.4F);
        }
        if (target instanceof ServerPlayer sp) {
            sp.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 40));
            sp.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1));
            playSound(SoundEvents.GHAST_SCREAM, 2.0F, 0.6F);
            sp.connection.send(new ClientboundSetTitlesAnimationPacket(0, 20, 10));
            sp.connection.send(new ClientboundSetTitleTextPacket(Component.literal("\u00a74\u00a7l!!!")));
        }
        return true;
    }

    @Override
    protected void dropCustomDeathLoot(DamageSource source, int looting, boolean recentlyHit) {
        super.dropCustomDeathLoot(source, looting, recentlyHit);
        for (int slot = 0; slot < 4; slot++) {
            int c = getSuit(slot);
            if (c > 0 && random.nextFloat() < 0.6F) {
                spawnAtLocation(new ItemStack(ModItems.PIECES.get(c - 1).get(slot).get()));
            }
        }
        int[] kindOfPart = {0, 0, 1, 2, 2, 3};
        for (int i = 0; i < 2; i++) {
            int part = random.nextInt(6);
            int type = Math.max(1, getEndo(part));
            spawnAtLocation(new ItemStack(ModItems.endoPart(type, kindOfPart[part])));
        }
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) { return SoundEvents.IRON_GOLEM_HURT; }

    @Override
    protected SoundEvent getDeathSound() { return SoundEvents.IRON_GOLEM_DEATH; }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        playSound(SoundEvents.IRON_GOLEM_STEP, 0.6F, 0.8F);
    }

    @Override
    public boolean removeWhenFarAway(double distance) { return false; }

    // ------------------------------------------------------------------ interaction

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (player.getItemInHand(hand).getItem() instanceof ServiceWrenchItem) {
            if (level().isClientSide) return InteractionResult.SUCCESS;
            if (player.isShiftKeyDown()) dock(player);
            else toggleMode(player);
            return InteractionResult.CONSUME;
        }
        return super.mobInteract(player, hand);
    }

    private void toggleMode(Player player) {
        int next = getMode() == MODE_SHOW ? MODE_NIGHT : MODE_SHOW;
        setMode(next);
        player.displayClientMessage(Component.literal(next == MODE_NIGHT
                ? "Mode: NIGHT (hunts at night, freezes when watched)"
                : "Mode: SHOW (friendly)"), true);
        playSound(SoundEvents.LEVER_CLICK, 1.0F, next == MODE_NIGHT ? 0.6F : 1.2F);
        setTarget(null);
    }

    /** Turn back into an Endo Stand block. */
    private void dock(Player player) {
        BlockPos pos = blockPosition();
        Level lvl = level();
        if (!lvl.getBlockState(pos).canBeReplaced() || !lvl.getBlockState(pos.above()).canBeReplaced()) {
            player.displayClientMessage(Component.literal("Not enough room to dock here."), true);
            return;
        }
        BlockState lower = ModBlocks.ENDO_STAND.get().defaultBlockState()
                .setValue(EndoStandBlock.FACING, Direction.fromYRot(getYRot()))
                .setValue(EndoStandBlock.HALF, DoubleBlockHalf.LOWER);
        lvl.setBlock(pos, lower, 3);
        lvl.setBlock(pos.above(), lower.setValue(EndoStandBlock.HALF, DoubleBlockHalf.UPPER), 3);
        if (lvl.getBlockEntity(pos) instanceof EndoStandBlockEntity be) {
            be.stage = 6;
            for (int i = 0; i < 6; i++) be.endo[i] = Math.max(1, getEndo(i));
            for (int i = 0; i < 4; i++) be.suit[i] = getSuit(i);
            be.sync();
        }
        discard();
    }
}
