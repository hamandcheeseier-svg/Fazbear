package com.fazbear.mod.block;

import com.fazbear.mod.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.List;

/** Stores which lights / doors a switch controls. */
public class LightSwitchBlockEntity extends BlockEntity {
    public static final int MAX_LINKS = 24;
    public final List<BlockPos> links = new ArrayList<>();

    public LightSwitchBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.LIGHT_SWITCH.get(), pos, state);
    }

    /** @return true if the position was added, false if it was removed */
    public boolean toggleLink(BlockPos pos) {
        BlockPos p = pos.immutable();
        boolean added;
        if (links.contains(p)) {
            links.remove(p);
            added = false;
        } else {
            links.add(p);
            added = true;
        }
        setChanged();
        return added;
    }

    public void clearLinks() {
        links.clear();
        setChanged();
    }

    /** Pushes the switch state to every linked block; drops links to blocks that are no longer linkable. */
    public void apply(Level level, boolean on) {
        boolean changed = false;
        for (BlockPos p : new ArrayList<>(links)) {
            if (!level.isLoaded(p)) continue;
            if (level.getBlockState(p).getBlock() instanceof Linkable l) {
                l.setActive(level, p, on);
            } else {
                links.remove(p);
                changed = true;
            }
        }
        if (changed) setChanged();
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        long[] arr = new long[links.size()];
        for (int i = 0; i < arr.length; i++) arr[i] = links.get(i).asLong();
        tag.putLongArray("Links", arr);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        links.clear();
        for (long l : tag.getLongArray("Links")) links.add(BlockPos.of(l));
    }
}
