package com.fazbear.mod.client;

import com.fazbear.mod.Suits;
import com.fazbear.mod.data.Box;
import com.fazbear.mod.data.CharacterDef;
import com.fazbear.mod.data.Characters;
import com.fazbear.mod.data.EndoTypeDef;
import com.fazbear.mod.data.EndoTypes;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.InventoryMenu;

/**
 * Draws an animatronic from box data (see GameData): every suit slot comes from whichever character's piece is
 * in it, every bare endo part from its endo type. Shared by the Endo Stand renderer and the walking entity renderer.
 * Coordinates are in pixels (16 = one block); the figure is 32 pixels (2 blocks) tall and faces -Z.
 */
public final class AnimatronicModel {
    private static final ResourceLocation DARK = new ResourceLocation("minecraft", "block/black_concrete");
    private static final ResourceLocation GLOW = new ResourceLocation("minecraft", "block/redstone_block");
    /** endo part indices that belong to each suit slot: head, torso, arms, legs */
    private static final int[][] PARTS_FOR_SLOT = {{5}, {2}, {3, 4}, {0, 1}};

    private AnimatronicModel() {}

    /**
     * @param endo     endo type of each part (legL, legR, torso, armL, armR, head), 0 = not installed
     * @param suit     {head, torso, arms, legs} character ids, 0 = bare endo
     * @param plate    draw the stand's base plate
     * @param glowEyes red eyes (night mode)
     */
    public static void draw(PoseStack ps, VertexConsumer vc, int light, int overlay, int[] endo, int[] suit,
                            boolean plate, boolean glowEyes, float legSwing, float armSwing, float headYaw) {
        Painter p = new Painter(ps, vc, light, overlay);
        if (plate) p.box(DARK, 2, 0, 2, 14, 1, 14);

        slot(p, ps, Suits.LEGS, endo, suit, glowEyes, legSwing, armSwing);
        slot(p, ps, Suits.TORSO, endo, suit, glowEyes, legSwing, armSwing);
        slot(p, ps, Suits.ARMS, endo, suit, glowEyes, legSwing, armSwing);

        ps.pushPose();
        ps.translate(0.5, 0, 0.5);
        ps.mulPose(Axis.YP.rotationDegrees(-headYaw));
        ps.translate(-0.5, 0, -0.5);
        slot(p, ps, Suits.HEAD, endo, suit, glowEyes, legSwing, armSwing);
        ps.popPose();
    }

    private static void slot(Painter p, PoseStack ps, int slot, int[] endo, int[] suit, boolean glow,
                             float legSwing, float armSwing) {
        CharacterDef def = Characters.get(suit[slot]);
        if (def != null) {
            for (Box b : def.slots[slot]) {
                ResourceLocation tex = (glow && b.tex == CharacterDef.EYE) ? GLOW : def.tex[b.tex];
                swung(p, ps, b, tex, slot, legSwing, armSwing);
            }
            return;
        }
        for (int part : PARTS_FOR_SLOT[slot]) {
            EndoTypeDef t = EndoTypes.get(endo[part]);
            if (t == null) continue;
            for (Box b : t.parts[part]) {
                ResourceLocation tex = (glow && b.tex == EndoTypeDef.EYE) ? GLOW : t.tex[b.tex];
                swung(p, ps, b, tex, slot, legSwing, armSwing);
            }
        }
    }

    private static void swung(Painter p, PoseStack ps, Box b, ResourceLocation tex, int slot, float legSwing, float armSwing) {
        if (b.side != 0 && slot == Suits.LEGS) {
            limb(ps, 13f, b.side < 0 ? legSwing : -legSwing);
            p.box(tex, b.x1, b.y1, b.z1, b.x2, b.y2, b.z2);
            ps.popPose();
        } else if (b.side != 0 && slot == Suits.ARMS) {
            limb(ps, 22f, b.side < 0 ? -armSwing : armSwing);
            p.box(tex, b.x1, b.y1, b.z1, b.x2, b.y2, b.z2);
            ps.popPose();
        } else {
            p.box(tex, b.x1, b.y1, b.z1, b.x2, b.y2, b.z2);
        }
    }

    /** Pushes a pose rotated about the X axis around a pivot at the given height (pixels), centred front-to-back. */
    private static void limb(PoseStack ps, float pivotY, float angle) {
        ps.pushPose();
        ps.translate(0, pivotY / 16f, 0.5);
        ps.mulPose(Axis.XP.rotationDegrees(angle));
        ps.translate(0, -pivotY / 16f, -0.5);
    }

    /** Emits textured boxes into the block atlas. */
    private static final class Painter {
        private final PoseStack ps;
        private final VertexConsumer vc;
        private final int light, overlay;

        Painter(PoseStack ps, VertexConsumer vc, int light, int overlay) {
            this.ps = ps; this.vc = vc; this.light = light; this.overlay = overlay;
        }

        void box(ResourceLocation tex, float x1, float y1, float z1, float x2, float y2, float z2) {
            x1 /= 16f; y1 /= 16f; z1 /= 16f; x2 /= 16f; y2 /= 16f; z2 /= 16f;
            TextureAtlasSprite s = Minecraft.getInstance().getTextureAtlas(InventoryMenu.BLOCK_ATLAS).apply(tex);
            float u0 = s.getU0(), u1 = s.getU1(), v0 = s.getV0(), v1 = s.getV1();
            PoseStack.Pose p = ps.last();
            quad(p, x2,y1,z1, x1,y1,z1, x1,y2,z1, x2,y2,z1, u0,u1,v0,v1,  0, 0,-1); // north
            quad(p, x1,y1,z2, x2,y1,z2, x2,y2,z2, x1,y2,z2, u0,u1,v0,v1,  0, 0, 1); // south
            quad(p, x2,y1,z2, x2,y1,z1, x2,y2,z1, x2,y2,z2, u0,u1,v0,v1,  1, 0, 0); // east
            quad(p, x1,y1,z1, x1,y1,z2, x1,y2,z2, x1,y2,z1, u0,u1,v0,v1, -1, 0, 0); // west
            quad(p, x1,y2,z2, x2,y2,z2, x2,y2,z1, x1,y2,z1, u0,u1,v0,v1,  0, 1, 0); // up
            quad(p, x1,y1,z1, x2,y1,z1, x2,y1,z2, x1,y1,z2, u0,u1,v0,v1,  0,-1, 0); // down
        }

        private void quad(PoseStack.Pose p,
                          float ax, float ay, float az, float bx, float by, float bz,
                          float cx, float cy, float cz, float dx, float dy, float dz,
                          float u0, float u1, float v0, float v1, float nx, float ny, float nz) {
            vert(p, ax, ay, az, u0, v1, nx, ny, nz);
            vert(p, bx, by, bz, u1, v1, nx, ny, nz);
            vert(p, cx, cy, cz, u1, v0, nx, ny, nz);
            vert(p, dx, dy, dz, u0, v0, nx, ny, nz);
        }

        private void vert(PoseStack.Pose p, float x, float y, float z, float u, float v, float nx, float ny, float nz) {
            vc.vertex(p.pose(), x, y, z).color(255, 255, 255, 255).uv(u, v)
                    .overlayCoords(overlay).uv2(light).normal(p.normal(), nx, ny, nz).endVertex();
        }
    }
}
