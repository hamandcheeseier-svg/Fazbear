package com.fazbear.mod.item;

import net.minecraft.world.item.Item;

/** A piece of endoskeleton (kind 0 leg, 1 torso, 2 arm, 3 head) of a given endo type (1 = Endo 01, 2 = Endo 02, 3 = Yenndo). */
public class EndoPartItem extends Item {
    private final int kind;
    private final int type;

    public EndoPartItem(int kind, int type, Properties props) {
        super(props);
        this.kind = kind;
        this.type = type;
    }

    public int getKind() { return kind; }
    public int getType() { return type; }
}
