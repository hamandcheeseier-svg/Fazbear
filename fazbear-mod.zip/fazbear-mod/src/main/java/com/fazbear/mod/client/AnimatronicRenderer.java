package com.fazbear.mod.client;

import com.fazbear.mod.entity.AnimatronicEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.inventory.InventoryMenu;

/** Renders the walking animatronic with walk-cycle limb swing, head tracking, and red eyes in night mode. */
public class AnimatronicRenderer extends EntityRenderer<AnimatronicEntity> {
    public AnimatronicRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.shadowRadius = 0.5F;
    }

    @Override
    public ResourceLocation getTextureLocation(AnimatronicEntity entity) {
        return InventoryMenu.BLOCK_ATLAS;
    }

    @Override
    public void render(AnimatronicEntity e, float entityYaw, float partialTick, PoseStack ps,
                       MultiBufferSource buffers, int light) {
        float body = Mth.rotLerp(partialTick, e.yBodyRotO, e.yBodyRot);
        float head = Mth.rotLerp(partialTick, e.yHeadRotO, e.yHeadRot) - body;
        head = Mth.clamp(Mth.wrapDegrees(head), -60.0F, 60.0F);

        float time = e.tickCount + partialTick;
        double speed = Math.hypot(e.getX() - e.xo, e.getZ() - e.zo);
        float amp = (float) Math.min(1.0D, speed * 5.0D);
        float swing = Mth.sin(time * 0.7F) * 40.0F * amp;
        if (e.isStunned()) head += Mth.sin(time * 2.5F) * 12.0F;

        ps.pushPose();
        ps.mulPose(Axis.YP.rotationDegrees(180.0F - body));
        ps.translate(-0.5, 0, -0.5);
        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(InventoryMenu.BLOCK_ATLAS));
        AnimatronicModel.draw(ps, vc, light, net.minecraft.client.renderer.texture.OverlayTexture.NO_OVERLAY,
                e.endoArray(), e.suitArray(), false, e.getMode() == AnimatronicEntity.MODE_NIGHT, swing, swing, head);
        ps.popPose();

        super.render(e, entityYaw, partialTick, ps, buffers, light);
    }
}
