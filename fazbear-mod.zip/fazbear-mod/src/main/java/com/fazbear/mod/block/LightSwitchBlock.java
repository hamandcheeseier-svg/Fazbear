package com.fazbear.mod.block;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.VoxelShape;
import com.fazbear.mod.item.ServiceWrenchItem;
import org.jetbrains.annotations.Nullable;

/**
 * Switch box. Right-click to flip it; every linked light / security door follows.
 * Link with the Service Wrench: click the switch (selects it), then click each light or door.
 */
public class LightSwitchBlock extends FacingBlock implements EntityBlock {
    public static final BooleanProperty ON = BooleanProperty.create("on");

    public LightSwitchBlock(Properties props, VoxelShape shape) {
        super(props, shape);
        registerDefaultState(defaultBlockState().setValue(ON, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        super.createBlockStateDefinition(builder);
        builder.add(ON);
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new LightSwitchBlockEntity(pos, state);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        ItemStack held = player.getItemInHand(hand);
        if (held.getItem() instanceof ServiceWrenchItem) {
            if (!level.isClientSide) {
                ServiceWrenchItem.select(held, level, pos);
                int n = level.getBlockEntity(pos) instanceof LightSwitchBlockEntity be ? be.links.size() : 0;
                player.displayClientMessage(Component.literal("Switch selected (" + n
                        + " linked). Right-click lights or doors to link them."), true);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (!level.isClientSide) {
            boolean on = !state.getValue(ON);
            level.setBlock(pos, state.setValue(ON, on), 3);
            level.playSound(null, pos, SoundEvents.LEVER_CLICK, SoundSource.BLOCKS, 0.8F, on ? 0.7F : 0.5F);
            if (level.getBlockEntity(pos) instanceof LightSwitchBlockEntity be) be.apply(level, on);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
