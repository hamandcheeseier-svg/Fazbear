package com.fazbear.mod.block;

import com.fazbear.mod.item.ServiceWrenchItem;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/** Wrench-on-linkable-block logic shared by lights, doors, etc. */
public final class WrenchLinking {
    private WrenchLinking() {}

    /**
     * @return true if the wrench has a switch selected and this block is Linkable, i.e. the click was handled
     *         (linked / unlinked / error message). False means: do the block's normal wrench action (e.g. rotate).
     */
    public static boolean handle(Level level, BlockPos pos, BlockState state, Player player, ItemStack wrench) {
        if (!(state.getBlock() instanceof Linkable) || !ServiceWrenchItem.hasSelection(wrench)) return false;
        if (level.isClientSide) return true;

        CompoundTag tag = wrench.getTag();
        BlockPos switchPos = BlockPos.of(tag.getLong("SwitchPos"));
        if (!tag.getString("SwitchDim").equals(level.dimension().location().toString())) {
            player.displayClientMessage(Component.literal("That switch is in another dimension."), true);
            return true;
        }
        if (!(level.getBlockEntity(switchPos) instanceof LightSwitchBlockEntity be)) {
            ServiceWrenchItem.clearSelection(wrench);
            player.displayClientMessage(Component.literal("The selected switch is gone."), true);
            return true;
        }
        if (switchPos.distSqr(pos) > 48.0D * 48.0D) {
            player.displayClientMessage(Component.literal("Too far from the switch (max 48 blocks)."), true);
            return true;
        }
        if (be.links.size() >= LightSwitchBlockEntity.MAX_LINKS && !be.links.contains(pos)) {
            player.displayClientMessage(Component.literal("This switch is full (" + LightSwitchBlockEntity.MAX_LINKS + " links)."), true);
            return true;
        }
        boolean added = be.toggleLink(pos);
        player.displayClientMessage(Component.literal(added
                ? "Linked! (" + be.links.size() + " on this switch)"
                : "Unlinked. (" + be.links.size() + " on this switch)"), true);
        return true;
    }
}
