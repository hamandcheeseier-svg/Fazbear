package com.fazbear.mod.block;

import com.fazbear.mod.item.ServiceWrenchItem;
import com.fazbear.mod.power.PowerNetwork;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Ceiling light panel. Toggle by hand or link it to a Light Switch with the Service Wrench.
 * If a Power Core is within 32 blocks the light drains 1 power per second and dies when the power does.
 */
public class FazLightBlock extends Block implements Linkable {
    public static final BooleanProperty LIT = BlockStateProperties.LIT;
    private static final VoxelShape SHAPE = Block.box(1, 13, 1, 15, 16, 15);

    public FazLightBlock(Properties props) {
        super(props);
        registerDefaultState(stateDefinition.any().setValue(LIT, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(LIT);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPE;
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        ItemStack held = player.getItemInHand(hand);
        if (held.getItem() instanceof ServiceWrenchItem) {
            if (WrenchLinking.handle(level, pos, state, player, held)) return InteractionResult.sidedSuccess(level.isClientSide);
            return InteractionResult.PASS;
        }
        if (!level.isClientSide) setActive(level, pos, !state.getValue(LIT));
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    public void setActive(Level level, BlockPos pos, boolean active) {
        BlockState state = level.getBlockState(pos);
        if (!state.is(this) || state.getValue(LIT) == active) return;
        if (active) {
            var core = PowerNetwork.nearest(level, pos, 32.0D);
            if (core != null && core.charge <= 0) {
                level.playSound(null, pos, SoundEvents.REDSTONE_TORCH_BURNOUT, SoundSource.BLOCKS, 0.5F, 0.6F);
                return;
            }
            level.setBlock(pos, state.setValue(LIT, true), 3);
            level.scheduleTick(pos, this, 20);
        } else {
            level.setBlock(pos, state.setValue(LIT, false), 3);
        }
        level.playSound(null, pos, SoundEvents.COMPARATOR_CLICK, SoundSource.BLOCKS, 0.6F, active ? 1.2F : 0.8F);
    }

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (!state.getValue(LIT)) return;
        var core = PowerNetwork.nearest(level, pos, 32.0D);
        if (core != null && !core.consume(1)) {
            level.setBlock(pos, state.setValue(LIT, false), 3);
            level.playSound(null, pos, SoundEvents.REDSTONE_TORCH_BURNOUT, SoundSource.BLOCKS, 0.5F, 0.6F);
        } else {
            level.scheduleTick(pos, this, 20);
        }
    }
}
