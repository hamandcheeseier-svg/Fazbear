package com.fazbear.mod.item;

import com.fazbear.mod.world.PizzeriaBuilder;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

/** Right-click the ground to build a pizzeria in front of you (it clears the space it uses). */
public class PizzeriaBlueprintItem extends Item {
    public PizzeriaBlueprintItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        if (level.isClientSide) return InteractionResult.SUCCESS;

        Direction forward = ctx.getHorizontalDirection();
        BlockPos origin = ctx.getClickedPos();
        PizzeriaBuilder.build(level, origin, forward);

        Player player = ctx.getPlayer();
        if (player != null) {
            player.displayClientMessage(Component.literal("Pizzeria built! The show stage is at the back."), true);
            if (!player.getAbilities().instabuild) ctx.getItemInHand().shrink(1);
        }
        return InteractionResult.CONSUME;
    }
}
