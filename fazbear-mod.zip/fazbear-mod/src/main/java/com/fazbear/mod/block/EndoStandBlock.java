package com.fazbear.mod.block;

import com.fazbear.mod.Performance;
import com.fazbear.mod.Suits;
import com.fazbear.mod.data.Characters;
import com.fazbear.mod.item.EndoPartItem;
import com.fazbear.mod.item.FullSuitItem;
import com.fazbear.mod.item.ServiceWrenchItem;
import com.fazbear.mod.item.SuitPieceItem;
import com.fazbear.mod.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.jetbrains.annotations.Nullable;

/**
 * Two-block-tall stand. Build the endoskeleton one part at a time (leg, leg, torso, arm, arm, head) using ANY
 * endo type per part (Endo 01 / Endo 02 / Yenndo), then fit suit pieces from ANY character into each slot.
 * Right-clicking with a different suit piece swaps it. Sneak + empty hand removes things (suit first, then endo).
 * Redstone power makes a fully dressed animatronic perform. Faz Key wakes it up.
 */
public class EndoStandBlock extends Block implements EntityBlock {
    public static final EnumProperty<DoubleBlockHalf> HALF = BlockStateProperties.DOUBLE_BLOCK_HALF;
    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;

    private static final VoxelShape SHAPE = Block.box(1, 0, 1, 15, 16, 15);

    public EndoStandBlock(Properties props) {
        super(props);
        registerDefaultState(stateDefinition.any()
                .setValue(HALF, DoubleBlockHalf.LOWER)
                .setValue(FACING, Direction.NORTH));
    }

    private static ItemStack pieceStack(int character, int slot) {
        return new ItemStack(ModItems.PIECES.get(character - 1).get(slot).get());
    }

    private static ItemStack endoStack(int type, int kind) {
        return new ItemStack(ModItems.endoPart(type, kind));
    }

    private static BlockPos lowerOf(BlockState state, BlockPos pos) {
        return state.getValue(HALF) == DoubleBlockHalf.LOWER ? pos : pos.below();
    }

    // ------------------------------------------------------------------ block basics

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(HALF, FACING);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.ENTITYBLOCK_ANIMATED;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPE;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return state.getValue(HALF) == DoubleBlockHalf.LOWER ? new EndoStandBlockEntity(pos, state) : null;
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        BlockPos pos = ctx.getClickedPos();
        Level level = ctx.getLevel();
        if (pos.getY() < level.getMaxBuildHeight() - 1 && level.getBlockState(pos.above()).canBeReplaced(ctx)) {
            return defaultBlockState()
                    .setValue(FACING, ctx.getHorizontalDirection().getOpposite())
                    .setValue(HALF, DoubleBlockHalf.LOWER);
        }
        return null;
    }

    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        level.setBlock(pos.above(), state.setValue(HALF, DoubleBlockHalf.UPPER), 3);
    }

    @Override
    public BlockState updateShape(BlockState state, Direction dir, BlockState neighbor,
                                  LevelAccessor level, BlockPos pos, BlockPos neighborPos) {
        DoubleBlockHalf half = state.getValue(HALF);
        boolean otherDir = dir == (half == DoubleBlockHalf.LOWER ? Direction.UP : Direction.DOWN);
        if (otherDir) {
            if (neighbor.is(this) && neighbor.getValue(HALF) != half) return state;
            return Blocks.AIR.defaultBlockState();
        }
        return super.updateShape(state, dir, neighbor, level, pos, neighborPos);
    }

    @Override
    public ItemStack getCloneItemStack(BlockGetter level, BlockPos pos, BlockState state) {
        return new ItemStack(ModItems.ENDO_STAND.get());
    }

    // ------------------------------------------------------------------ interaction

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        BlockPos lowerPos = lowerOf(state, pos);
        BlockState lower = level.getBlockState(lowerPos);
        if (!lower.is(this)) return InteractionResult.PASS;
        if (!(level.getBlockEntity(lowerPos) instanceof EndoStandBlockEntity be)) return InteractionResult.PASS;

        ItemStack held = player.getItemInHand(hand);
        boolean server = !level.isClientSide;
        InteractionResult ok = InteractionResult.sidedSuccess(level.isClientSide);

        // wrench: rotate
        if (held.getItem() instanceof ServiceWrenchItem) {
            if (server) {
                BlockState rotated = lower.setValue(FACING, lower.getValue(FACING).getClockWise());
                level.setBlock(lowerPos, rotated, 3);
                level.setBlock(lowerPos.above(), rotated.setValue(HALF, DoubleBlockHalf.UPPER), 3);
            }
            return ok;
        }

        // 1) next endoskeleton part (any endo type, but the right kind)
        if (be.stage < 6 && held.getItem() instanceof EndoPartItem part && part.getKind() == Suits.KIND_FOR_STAGE[be.stage]) {
            if (server) {
                if (!player.getAbilities().instabuild) held.shrink(1);
                be.endo[be.stage] = part.getType();
                be.stage++;
                be.sync();
                level.playSound(null, lowerPos, SoundType.CHAIN.getPlaceSound(), SoundSource.BLOCKS, 1f, 0.9f);
                msg(player, be.stage == 6
                        ? Component.literal("Endoskeleton complete! Fit suit pieces onto it.")
                        : Component.literal("Part installed (" + be.stage + "/6)"));
            }
            return ok;
        }

        // 2) one suit piece (any character) - swaps if the slot is already filled
        if (held.getItem() instanceof SuitPieceItem piece) {
            int slot = piece.getSlot();
            int ch = piece.getCharacter();
            if (be.stage < Suits.REQUIRED_STAGE[slot]) {
                if (server) msg(player, Component.literal("Install the endo " + Suits.NEEDS[slot] + " first."));
                return ok;
            }
            if (be.suit[slot] == ch) return ok;
            if (server) {
                int old = be.suit[slot];
                be.suit[slot] = ch;
                if (!player.getAbilities().instabuild) held.shrink(1);
                if (old > 0) give(player, pieceStack(old, slot));
                be.sync();
                level.playSound(null, lowerPos, SoundType.WOOL.getPlaceSound(), SoundSource.BLOCKS, 1f, 0.8f);
                msg(player, Component.literal(Characters.nameOf(ch) + " " + Suits.SLOT_NAMES[slot].toLowerCase() + " fitted."));
            }
            return ok;
        }

        // 3) full matching suit - replaces every slot
        if (held.getItem() instanceof FullSuitItem full) {
            if (be.stage < 6) {
                if (server) msg(player, Component.literal("Finish the endoskeleton first."));
                return ok;
            }
            if (server) {
                for (int slot = 0; slot < 4; slot++) {
                    if (be.suit[slot] > 0) give(player, pieceStack(be.suit[slot], slot));
                    be.suit[slot] = full.getCharacter();
                }
                if (!player.getAbilities().instabuild) held.shrink(1);
                be.sync();
                level.playSound(null, lowerPos, SoundType.WOOL.getPlaceSound(), SoundSource.BLOCKS, 1f, 0.7f);
                msg(player, Component.literal(Characters.nameOf(full.getCharacter()) + " is ready for the show!"));
            }
            return ok;
        }

        // 4) sneak + empty hand: undo (suit pieces first: head, torso, arms, legs; then endo parts)
        if (held.isEmpty() && player.isShiftKeyDown() && (be.hasAnySuit() || be.stage > 0)) {
            if (server) {
                ItemStack back = ItemStack.EMPTY;
                for (int slot = 0; slot < 4 && back.isEmpty(); slot++) {
                    if (be.suit[slot] > 0) {
                        back = pieceStack(be.suit[slot], slot);
                        be.suit[slot] = 0;
                    }
                }
                if (back.isEmpty()) {
                    be.stage--;
                    back = endoStack(be.endo[be.stage], Suits.KIND_FOR_STAGE[be.stage]);
                    be.endo[be.stage] = 0;
                }
                give(player, back);
                be.sync();
                level.playSound(null, lowerPos, SoundType.CHAIN.getPlaceSound(), SoundSource.BLOCKS, 1f, 1.2f);
            }
            return ok;
        }

        // 5) status hint
        if (held.isEmpty() || held.getItem() instanceof EndoPartItem) {
            if (server && hand == InteractionHand.MAIN_HAND) msg(player, describe(be));
            return ok;
        }
        return InteractionResult.PASS;
    }

    private static Component describe(EndoStandBlockEntity be) {
        if (be.stage < 6) {
            return Component.literal("Endo " + be.stage + "/6. Next part: "
                    + Suits.KIND_NAMES[Suits.KIND_FOR_STAGE[be.stage]]);
        }
        StringBuilder sb = new StringBuilder("Endo done. ");
        for (int s = 0; s < 4; s++) {
            sb.append(Suits.SLOT_NAMES[s]).append(": ").append(Characters.nameOf(be.suit[s])).append(s < 3 ? " | " : "");
        }
        return Component.literal(sb.toString());
    }

    private static void msg(Player player, Component c) {
        player.displayClientMessage(c, true);
    }

    private static void give(Player player, ItemStack stack) {
        if (!player.getInventory().add(stack)) player.drop(stack, false);
    }

    // ------------------------------------------------------------------ redstone performance

    private static boolean isPowered(Level level, BlockPos lowerPos) {
        return level.hasNeighborSignal(lowerPos) || level.hasNeighborSignal(lowerPos.above());
    }

    @Override
    public void neighborChanged(BlockState state, Level level, BlockPos pos, Block block, BlockPos fromPos, boolean moving) {
        if (level.isClientSide) return;
        BlockPos lowerPos = lowerOf(state, pos);
        if (isPowered(level, lowerPos) && !level.getBlockTicks().hasScheduledTick(lowerPos, this)) {
            level.scheduleTick(lowerPos, this, 2);
        }
    }

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (state.getValue(HALF) != DoubleBlockHalf.LOWER) return;
        if (!(level.getBlockEntity(pos) instanceof EndoStandBlockEntity be)) return;
        if (!isPowered(level, pos) || !be.isComplete()) return;
        Performance.step(level, pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, be.suit, be.musicStep++);
        level.scheduleTick(pos, this, 6);
    }

    // ------------------------------------------------------------------ breaking

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        if (!level.isClientSide && !player.isCreative()) {
            BlockPos lowerPos = lowerOf(state, pos);
            popResource(level, lowerPos, new ItemStack(ModItems.ENDO_STAND.get()));
            if (level.getBlockEntity(lowerPos) instanceof EndoStandBlockEntity be) {
                for (int i = 0; i < be.stage; i++) {
                    popResource(level, lowerPos, endoStack(be.endo[i], Suits.KIND_FOR_STAGE[i]));
                }
                for (int slot = 0; slot < 4; slot++) {
                    if (be.suit[slot] > 0) popResource(level, lowerPos, pieceStack(be.suit[slot], slot));
                }
            }
        }
        super.playerWillDestroy(level, pos, state, player);
    }
}
