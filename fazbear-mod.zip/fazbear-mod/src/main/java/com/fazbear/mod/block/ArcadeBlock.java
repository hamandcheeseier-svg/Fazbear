package com.fazbear.mod.block;

import com.fazbear.mod.Performance;
import com.fazbear.mod.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Plays a jingle and sometimes spits out a Faz Token. */
public class ArcadeBlock extends FacingBlock {
    public ArcadeBlock(Properties props, VoxelShape shape) {
        super(props, shape);
    }

    @Override
    protected InteractionResult interact(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand) {
        if (player.getCooldowns().isOnCooldown(ModItems.FAZ_TOKEN.get())) return InteractionResult.sidedSuccess(level.isClientSide);
        if (!level.isClientSide) {
            double x = pos.getX() + 0.5, y = pos.getY() + 0.5, z = pos.getZ() + 0.5;
            int[] jingle = {12, 16, 19, 24};
            for (int i = 0; i < jingle.length; i++) {
                Performance.note(level, x, y, z, "bit", Performance.pitch(jingle[(i + level.random.nextInt(4)) % 4]), 1.0F);
            }
            if (level.random.nextInt(4) == 0) {
                popResource(level, pos.above(), new ItemStack(ModItems.FAZ_TOKEN.get()));
                Performance.note(level, x, y, z, "pling", 2.0F, 1.0F);
            }
            player.getCooldowns().addCooldown(ModItems.FAZ_TOKEN.get(), 60);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
