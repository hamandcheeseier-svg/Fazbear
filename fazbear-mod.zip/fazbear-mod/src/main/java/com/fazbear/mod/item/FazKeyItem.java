package com.fazbear.mod.item;

import com.fazbear.mod.block.EndoStandBlock;
import com.fazbear.mod.block.EndoStandBlockEntity;
import com.fazbear.mod.entity.AnimatronicEntity;
import com.fazbear.mod.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;

/** Right-click a finished Endo Stand to wake the animatronic up as a walking entity. */
public class FazKeyItem extends Item {
    public FazKeyItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        BlockPos pos = ctx.getClickedPos();
        BlockState state = level.getBlockState(pos);
        if (!(state.getBlock() instanceof EndoStandBlock)) return InteractionResult.PASS;

        BlockPos lowerPos = state.getValue(EndoStandBlock.HALF) == DoubleBlockHalf.LOWER ? pos : pos.below();
        if (!(level.getBlockEntity(lowerPos) instanceof EndoStandBlockEntity be)) return InteractionResult.PASS;
        Player player = ctx.getPlayer();

        if (be.stage < 6) {
            if (!level.isClientSide && player != null) {
                player.displayClientMessage(Component.literal("Finish the endoskeleton before waking it up."), true);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (level.isClientSide) return InteractionResult.SUCCESS;

        AnimatronicEntity e = ModEntities.ANIMATRONIC.get().create(level);
        if (e == null) return InteractionResult.FAIL;
        Direction facing = level.getBlockState(lowerPos).getValue(EndoStandBlock.FACING);
        e.moveTo(lowerPos.getX() + 0.5, lowerPos.getY(), lowerPos.getZ() + 0.5, facing.toYRot(), 0.0F);
        e.setYBodyRot(facing.toYRot());
        e.setYHeadRot(facing.toYRot());
        e.setEndo(be.endo);
        e.setSuit(be.suit);
        e.setHealth(e.getMaxHealth());

        level.removeBlock(lowerPos.above(), false);
        level.removeBlock(lowerPos, false);
        level.addFreshEntity(e);
        level.playSound(null, lowerPos, SoundEvents.IRON_GOLEM_REPAIR, SoundSource.BLOCKS, 1.0F, 0.7F);
        if (player != null) {
            player.displayClientMessage(Component.literal("It's awake. Wrench = toggle SHOW/NIGHT, sneak + wrench = dock."), true);
        }
        return InteractionResult.CONSUME;
    }
}
