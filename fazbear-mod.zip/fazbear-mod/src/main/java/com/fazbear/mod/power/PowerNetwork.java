package com.fazbear.mod.power;

import com.fazbear.mod.block.PowerCoreBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/** Keeps track of loaded Power Cores per dimension (server side) so doors can find the nearest one. */
public final class PowerNetwork {
    private static final Map<ResourceKey<Level>, Set<BlockPos>> CORES = new HashMap<>();

    private PowerNetwork() {}

    public static void register(Level level, BlockPos pos) {
        if (level.isClientSide) return;
        CORES.computeIfAbsent(level.dimension(), k -> new HashSet<>()).add(pos.immutable());
    }

    public static void unregister(Level level, BlockPos pos) {
        if (level.isClientSide) return;
        Set<BlockPos> set = CORES.get(level.dimension());
        if (set != null) set.remove(pos);
    }

    /** Nearest loaded Power Core within range blocks, or null. */
    @Nullable
    public static PowerCoreBlockEntity nearest(Level level, BlockPos from, double range) {
        Set<BlockPos> set = CORES.get(level.dimension());
        if (set == null) return null;
        PowerCoreBlockEntity best = null;
        double bestDist = range * range;
        for (BlockPos p : set) {
            double d = p.distSqr(from);
            if (d <= bestDist && level.getBlockEntity(p) instanceof PowerCoreBlockEntity core) {
                best = core;
                bestDist = d;
            }
        }
        return best;
    }
}
