package com.fazbear.mod.block;

import com.fazbear.mod.power.PowerNetwork;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Blast door. Needs a Power Core within 32 blocks; each closed door block drains 1 power per second.
 * Blocks animatronics. Can be linked to a Light Switch with the Service Wrench (switch ON = door closed).
 */
public class SecurityDoorBlock extends PlateBlock implements Linkable {
    public SecurityDoorBlock(Properties props) {
        super(props, 4, 2);
    }

    /** @return false if there is no power */
    private boolean close(Level level, BlockPos pos, BlockState state) {
        var core = PowerNetwork.nearest(level, pos, 32.0D);
        if (core == null || core.charge <= 0) {
            level.playSound(null, pos, SoundEvents.IRON_DOOR_OPEN, SoundSource.BLOCKS, 0.5F, 0.4F);
            return false;
        }
        level.setBlock(pos, state.setValue(OPEN, false), 3);
        level.playSound(null, pos, SoundEvents.IRON_DOOR_CLOSE, SoundSource.BLOCKS, 1.0F, 0.8F);
        level.scheduleTick(pos, this, 20);
        return true;
    }

    private void open(Level level, BlockPos pos, BlockState state) {
        level.setBlock(pos, state.setValue(OPEN, true), 3);
        level.playSound(null, pos, SoundEvents.IRON_DOOR_OPEN, SoundSource.BLOCKS, 1.0F, 0.8F);
    }

    @Override
    protected InteractionResult interact(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        if (state.getValue(OPEN)) {
            if (!close(level, pos, state)) {
                player.displayClientMessage(Component.literal(
                        PowerNetwork.nearest(level, pos, 32.0D) == null ? "No Power Core nearby." : "No power!"), true);
            }
        } else {
            open(level, pos, state);
        }
        return InteractionResult.CONSUME;
    }

    @Override
    public void setActive(Level level, BlockPos pos, boolean active) {
        BlockState state = level.getBlockState(pos);
        if (!state.is(this)) return;
        if (active && state.getValue(OPEN)) close(level, pos, state);
        else if (!active && !state.getValue(OPEN)) open(level, pos, state);
    }

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (state.getValue(OPEN)) return;
        var core = PowerNetwork.nearest(level, pos, 32.0D);
        if (core != null && core.consume(1)) {
            level.scheduleTick(pos, this, 20);
        } else {
            level.setBlock(pos, state.setValue(OPEN, true), 3);
            level.playSound(null, pos, SoundEvents.IRON_DOOR_OPEN, SoundSource.BLOCKS, 1.0F, 0.5F);
        }
    }
}
