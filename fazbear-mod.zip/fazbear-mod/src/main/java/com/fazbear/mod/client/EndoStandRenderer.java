package com.fazbear.mod.client;

import com.fazbear.mod.block.EndoStandBlock;
import com.fazbear.mod.block.EndoStandBlockEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.core.Direction;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.level.block.state.BlockState;

/** Draws whatever is on an Endo Stand. */
public class EndoStandRenderer implements BlockEntityRenderer<EndoStandBlockEntity> {
    public EndoStandRenderer(BlockEntityRendererProvider.Context ctx) {}

    @Override
    public void render(EndoStandBlockEntity be, float partialTick, PoseStack ps, MultiBufferSource buffers,
                       int light, int overlay) {
        BlockState state = be.getBlockState();
        if (!state.hasProperty(EndoStandBlock.FACING)) return;
        Direction facing = state.getValue(EndoStandBlock.FACING);

        ps.pushPose();
        ps.translate(0.5, 0, 0.5);
        ps.mulPose(Axis.YP.rotationDegrees(-((facing.get2DDataValue() * 90 + 180) % 360)));
        ps.translate(-0.5, 0, -0.5);
        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(InventoryMenu.BLOCK_ATLAS));
        AnimatronicModel.draw(ps, vc, light, overlay, be.endo, be.suit, true, false, 0f, 0f, 0f);
        ps.popPose();
    }
}
