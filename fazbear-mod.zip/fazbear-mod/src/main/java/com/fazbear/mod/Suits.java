package com.fazbear.mod;

/** Slot constants shared by blocks, entities and renderers. */
public final class Suits {
    public static final int HEAD = 0, TORSO = 1, ARMS = 2, LEGS = 3;
    public static final String[] SLOT_IDS = {"head", "torso", "arms", "legs"};
    public static final String[] SLOT_NAMES = {"Head", "Torso", "Arms", "Legs"};
    /** How many endo parts must be installed before a suit piece fits in each slot. */
    public static final int[] REQUIRED_STAGE = {6, 3, 5, 2};
    public static final String[] NEEDS = {"head", "torso", "both arms", "both legs"};

    /** Endo parts in install order: leg, leg, torso, arm, arm, head. Kinds: 0 leg, 1 torso, 2 arm, 3 head. */
    public static final int[] KIND_FOR_STAGE = {0, 0, 1, 2, 2, 3};
    public static final String[] KIND_IDS = {"leg", "torso", "arm", "head"};
    public static final String[] KIND_NAMES = {"Leg", "Torso", "Arm", "Head"};

    private Suits() {}
}
