package com.fazbear.mod;

import com.fazbear.mod.data.CharacterDef;
import com.fazbear.mod.data.Characters;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.Level;
import net.minecraftforge.registries.ForgeRegistries;

/** The tune animatronics play. Instruments come from the character whose piece is in each slot. */
public final class Performance {
    public static final int[] MELODY = {12, 16, 19, 24, 19, 16, 14, 17, 21, 17, 14, 12, 16, 19, 16, 12};

    private Performance() {}

    public static float pitch(int semitone) {
        return (float) Math.pow(2.0, (semitone - 12) / 12.0);
    }

    public static void note(Level level, double x, double y, double z, String instrument, float pitch, float volume) {
        SoundEvent ev = ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("minecraft", "block.note_block." + instrument));
        if (ev != null) level.playSound(null, x, y, z, ev, SoundSource.RECORDS, volume, pitch);
    }

    /** Plays one step of the song. suit = {head, torso, arms, legs} character ids (0 = none). */
    public static void step(Level level, double x, double y, double z, int[] suit, int step) {
        int s = Math.floorMod(step, MELODY.length);
        int n = MELODY[s];
        CharacterDef head = Characters.get(suit[Suits.HEAD]);
        CharacterDef arms = Characters.get(suit[Suits.ARMS]);
        CharacterDef legs = Characters.get(suit[Suits.LEGS]);
        note(level, x, y, z, head == null ? "iron_xylophone" : head.lead, pitch(n), 2.0F);
        note(level, x, y, z, arms == null ? "harp" : arms.harmony, pitch(n - 5), 1.5F);
        if (s % 2 == 0) note(level, x, y, z, legs == null ? "basedrum" : legs.rhythm, 1.0F, 1.5F);
        if (level instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.NOTE, x, y + 2.4, z, 0, (n - 12) / 24.0, 0, 0, 1.0);
        }
    }
}
