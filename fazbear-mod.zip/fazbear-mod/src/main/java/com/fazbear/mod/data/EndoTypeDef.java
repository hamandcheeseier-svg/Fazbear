package com.fazbear.mod.data;

import net.minecraft.resources.ResourceLocation;

/** An endoskeleton model (Endo 01, Endo 02, Yenndo...). Parts: 0 legL, 1 legR, 2 torso, 3 armL, 4 armR, 5 head. */
public final class EndoTypeDef {
    /** texture roles */
    public static final int METAL = 0, DARK = 1, CORE = 2, EYE = 3;

    public final int id;
    public final String key, name;
    public final float speedMod, damageMod, healthMod;
    public final ResourceLocation[] tex;
    public final Box[][] parts;

    public EndoTypeDef(int id, String key, String name, float speedMod, float damageMod, float healthMod,
                       ResourceLocation[] tex, Box[][] parts) {
        this.id = id; this.key = key; this.name = name;
        this.speedMod = speedMod; this.damageMod = damageMod; this.healthMod = healthMod;
        this.tex = tex; this.parts = parts;
    }
}
