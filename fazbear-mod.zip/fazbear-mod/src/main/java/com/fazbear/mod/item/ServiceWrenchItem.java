package com.fazbear.mod.item;

import com.fazbear.mod.block.LightSwitchBlock;
import com.fazbear.mod.block.LightSwitchBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * The Service Wrench.
 *  - rotates stands, plushies and decor
 *  - on an animatronic: toggle SHOW/NIGHT, sneak = dock
 *  - LINKING: right-click a Light Switch to select it (the wrench glows), then right-click lights / security
 *    doors to link or unlink them. Sneak + right-click a switch clears its links. Sneak + right-click air deselects.
 */
public class ServiceWrenchItem extends Item {
    public ServiceWrenchItem(Properties props) {
        super(props);
    }

    public static void select(ItemStack stack, Level level, BlockPos pos) {
        CompoundTag t = stack.getOrCreateTag();
        t.putLong("SwitchPos", pos.asLong());
        t.putString("SwitchDim", level.dimension().location().toString());
    }

    public static boolean hasSelection(ItemStack stack) {
        CompoundTag t = stack.getTag();
        return t != null && t.contains("SwitchPos");
    }

    public static void clearSelection(ItemStack stack) {
        CompoundTag t = stack.getTag();
        if (t == null) return;
        t.remove("SwitchPos");
        t.remove("SwitchDim");
        if (t.isEmpty()) stack.setTag(null);
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Player player = ctx.getPlayer();
        Level level = ctx.getLevel();
        if (player != null && player.isShiftKeyDown()
                && level.getBlockState(ctx.getClickedPos()).getBlock() instanceof LightSwitchBlock) {
            if (!level.isClientSide && level.getBlockEntity(ctx.getClickedPos()) instanceof LightSwitchBlockEntity be) {
                be.clearLinks();
                player.displayClientMessage(Component.literal("All links cleared."), true);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        return InteractionResult.PASS;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player.isShiftKeyDown() && hasSelection(stack)) {
            if (!level.isClientSide) {
                clearSelection(stack);
                player.displayClientMessage(Component.literal("Switch deselected."), true);
            }
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }
        return InteractionResultHolder.pass(stack);
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return hasSelection(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        super.appendHoverText(stack, level, tooltip, flag);
        if (hasSelection(stack)) {
            BlockPos p = BlockPos.of(stack.getTag().getLong("SwitchPos"));
            tooltip.add(Component.literal("Switch selected: " + p.getX() + ", " + p.getY() + ", " + p.getZ()));
            tooltip.add(Component.literal("Right-click lights / doors to link."));
        } else {
            tooltip.add(Component.literal("Right-click a Light Switch, then lights or doors, to link them."));
        }
    }
}
