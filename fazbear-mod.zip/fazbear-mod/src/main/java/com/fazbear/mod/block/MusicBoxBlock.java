package com.fazbear.mod.block;

import com.fazbear.mod.Performance;
import com.fazbear.mod.entity.AnimatronicEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Wind it up (right-click) and it plays a lullaby for 45 seconds, keeping animatronics within 32 blocks calm.
 * When it runs down, every animatronic nearby is enraged for 10 seconds. Keep it wound!
 */
public class MusicBoxBlock extends FacingBlock {
    public static final int MAX_WIND = 45;
    public static final IntegerProperty WIND = IntegerProperty.create("wind", 0, MAX_WIND);
    private static final int[] LULLABY = {19, 17, 14, 17, 19, 19, 19, 17, 17, 17, 19, 22, 22};

    public MusicBoxBlock(Properties props, VoxelShape shape) {
        super(props, shape);
        registerDefaultState(defaultBlockState().setValue(WIND, 0));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        super.createBlockStateDefinition(builder);
        builder.add(WIND);
    }

    @Override
    protected InteractionResult interact(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand) {
        if (!level.isClientSide) {
            boolean wasStopped = state.getValue(WIND) == 0;
            level.setBlock(pos, state.setValue(WIND, MAX_WIND), 3);
            level.playSound(null, pos, SoundEvents.LEVER_CLICK, SoundSource.BLOCKS, 1.0F, 1.5F);
            if (wasStopped) level.scheduleTick(pos, this, 20);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        int wind = state.getValue(WIND);
        if (wind <= 0) return;

        int n = LULLABY[(MAX_WIND - wind) % LULLABY.length];
        Performance.note(level, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, "chime", Performance.pitch(n), 2.0F);
        level.sendParticles(ParticleTypes.NOTE, pos.getX() + 0.5, pos.getY() + 1.1, pos.getZ() + 0.5, 0, (n - 12) / 24.0, 0, 0, 1.0);

        AABB area = new AABB(pos).inflate(32.0D);
        for (AnimatronicEntity e : level.getEntitiesOfClass(AnimatronicEntity.class, area)) e.pacify(60);

        int next = wind - 1;
        level.setBlock(pos, state.setValue(WIND, next), 3);
        if (next > 0) {
            level.scheduleTick(pos, this, 20);
        } else {
            level.playSound(null, pos, SoundEvents.ENDERMAN_STARE, SoundSource.BLOCKS, 2.0F, 0.5F);
            for (AnimatronicEntity e : level.getEntitiesOfClass(AnimatronicEntity.class, area)) e.enrage(200);
        }
    }
}
