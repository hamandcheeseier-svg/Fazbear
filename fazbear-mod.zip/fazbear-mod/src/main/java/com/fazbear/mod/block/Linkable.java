package com.fazbear.mod.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;

/** Implemented by blocks a Light Switch can control (lights, security doors). */
public interface Linkable {
    /** active = switch is ON. */
    void setActive(Level level, BlockPos pos, boolean active);
}
