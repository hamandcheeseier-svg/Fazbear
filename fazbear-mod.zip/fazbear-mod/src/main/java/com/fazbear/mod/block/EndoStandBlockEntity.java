package com.fazbear.mod.block;

import com.fazbear.mod.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

/** What is on the stand: endo parts (with their endo type) + which character's piece is in each suit slot. */
public class EndoStandBlockEntity extends BlockEntity {
    public int stage = 0;                   // endo parts installed, 0..6
    public final int[] endo = new int[6];   // endo type of each part: legL, legR, torso, armL, armR, head (0 = none)
    public final int[] suit = new int[4];   // head, torso, arms, legs -> 0 = none, else character id
    public int musicStep = 0;

    public EndoStandBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.ENDO_STAND.get(), pos, state);
    }

    public boolean hasAnySuit() {
        for (int s : suit) if (s > 0) return true;
        return false;
    }

    public boolean isComplete() {
        if (stage < 6) return false;
        for (int s : suit) if (s == 0) return false;
        return true;
    }

    public void sync() {
        setChanged();
        if (level != null) level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putInt("Stage", stage);
        tag.putIntArray("Endo", endo);
        tag.putIntArray("Suit", suit);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        stage = tag.getInt("Stage");
        int[] e = tag.getIntArray("Endo");
        for (int i = 0; i < 6; i++) endo[i] = i < e.length ? e[i] : (i < stage ? 1 : 0);
        int[] a = tag.getIntArray("Suit");
        for (int i = 0; i < 4; i++) suit[i] = i < a.length ? a[i] : 0;
    }

    @Override
    public CompoundTag getUpdateTag() {
        return saveWithoutMetadata();
    }

    @Override
    public ClientboundBlockEntityDataPacket getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    @Override
    public AABB getRenderBoundingBox() {
        return new AABB(worldPosition.getX() - 1, worldPosition.getY(), worldPosition.getZ() - 1,
                worldPosition.getX() + 2, worldPosition.getY() + 2.5, worldPosition.getZ() + 2);
    }
}
