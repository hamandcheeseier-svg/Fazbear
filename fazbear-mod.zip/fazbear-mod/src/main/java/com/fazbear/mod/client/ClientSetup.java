package com.fazbear.mod.client;

import com.fazbear.mod.FazbearMod;
import com.fazbear.mod.registry.ModBlockEntities;
import com.fazbear.mod.registry.ModEntities;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = FazbearMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {
    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerBlockEntityRenderer(ModBlockEntities.ENDO_STAND.get(), EndoStandRenderer::new);
        event.registerEntityRenderer(ModEntities.ANIMATRONIC.get(), AnimatronicRenderer::new);
    }
}
