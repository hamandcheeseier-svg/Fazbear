package com.fazbear.mod.block;

import com.fazbear.mod.Suits;
import com.fazbear.mod.data.Characters;
import com.fazbear.mod.power.PowerNetwork;
import com.fazbear.mod.entity.AnimatronicEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.shapes.VoxelShape;

import java.util.Comparator;
import java.util.List;

/** Right-click to see every animatronic within 48 blocks: who, how far, which direction, which mode. */
public class SecurityMonitorBlock extends FacingBlock {
    public SecurityMonitorBlock(Properties props, VoxelShape shape) {
        super(props, shape);
    }

    @Override
    protected InteractionResult interact(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        if (hand != InteractionHand.MAIN_HAND) return InteractionResult.CONSUME;

        List<AnimatronicEntity> list = level.getEntitiesOfClass(AnimatronicEntity.class, new AABB(pos).inflate(48.0D));
        list.sort(Comparator.comparingDouble(e -> e.distanceToSqr(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5)));
        var core = PowerNetwork.nearest(level, pos, 48.0D);
        player.sendSystemMessage(Component.literal("\u00a7a[Security] " + list.size() + " animatronic(s) in range"
                + (core == null ? "" : "  |  Power: " + core.percent() + "%")));
        int shown = 0;
        for (AnimatronicEntity e : list) {
            if (shown++ >= 6) break;
            double dx = e.getX() - (pos.getX() + 0.5), dz = e.getZ() - (pos.getZ() + 0.5);
            Direction dir = Direction.getNearest(dx, 0, dz);
            int head = e.getSuit(Suits.HEAD);
            String name = head > 0 ? Characters.nameOf(head) + " head" : "bare endo";
            String status = e.isStunned() ? "stunned" : e.isPacified() ? "calm" : e.getMode() == AnimatronicEntity.MODE_NIGHT ? "NIGHT" : "show";
            player.sendSystemMessage(Component.literal(" - " + name + ", " + (int) Math.sqrt(dx * dx + dz * dz)
                    + "m " + dir.getName() + " [" + status + "]"));
        }
        return InteractionResult.CONSUME;
    }
}
