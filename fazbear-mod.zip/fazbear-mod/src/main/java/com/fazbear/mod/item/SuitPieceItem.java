package com.fazbear.mod.item;

import net.minecraft.world.item.Item;

/** One piece of one character's suit. Right-click an Endo Stand to fit it (swaps with whatever is there). */
public class SuitPieceItem extends Item {
    private final int slot;
    private final int character;

    public SuitPieceItem(int slot, int character, Properties props) {
        super(props);
        this.slot = slot;
        this.character = character;
    }

    /** 0 head, 1 torso, 2 arms, 3 legs */
    public int getSlot() { return slot; }

    /** 1 Freddy, 2 Bonnie, 3 Chica, 4 Foxy, 5 Golden Freddy */
    public int getCharacter() { return character; }
}
