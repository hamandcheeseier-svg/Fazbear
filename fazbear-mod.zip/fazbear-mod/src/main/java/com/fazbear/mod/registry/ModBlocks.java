package com.fazbear.mod.registry;

import com.fazbear.mod.FazbearMod;
import com.fazbear.mod.block.*;
import com.fazbear.mod.data.Characters;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayList;
import java.util.List;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, FazbearMod.MODID);

    private static BlockBehaviour.Properties decor(MapColor color, SoundType sound) {
        return BlockBehaviour.Properties.of().mapColor(color).strength(1.5F).sound(sound).noOcclusion();
    }

    public static final RegistryObject<Block> ENDO_STAND = BLOCKS.register("endo_stand",
            () -> new EndoStandBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.METAL).strength(2.0F).sound(SoundType.METAL)
                    .noOcclusion().noLootTable()));

    public static final RegistryObject<Block> CHECKER_TILE = BLOCKS.register("checker_tile",
            () -> new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_BLACK).strength(1.5F).sound(SoundType.STONE)));
    public static final RegistryObject<Block> PARTY_WALL = BLOCKS.register("party_wall",
            () -> new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_PURPLE).strength(1.5F).sound(SoundType.STONE)));
    public static final RegistryObject<Block> SHOW_STAGE = BLOCKS.register("show_stage",
            () -> new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.WOOD).strength(2.0F).sound(SoundType.WOOD)));

    /** One plushie per character, same order as Characters.ALL */
    public static final List<RegistryObject<Block>> PLUSHIES = new ArrayList<>();
    static {
        for (var def : Characters.ALL) {
            PLUSHIES.add(BLOCKS.register("plush_" + def.key,
                    () -> new PlushBlock(BlockBehaviour.Properties.of()
                            .mapColor(MapColor.WOOL).strength(0.4F).sound(SoundType.WOOL).noOcclusion())));
        }
    }

    public static final RegistryObject<Block> ARCADE_CABINET = BLOCKS.register("arcade_cabinet",
            () -> new ArcadeBlock(decor(MapColor.COLOR_BLUE, SoundType.METAL), Block.box(2, 0, 2, 14, 16, 14)));
    public static final RegistryObject<Block> PRIZE_COUNTER = BLOCKS.register("prize_counter",
            () -> new PrizeCounterBlock(decor(MapColor.WOOD, SoundType.WOOD), Block.box(0, 0, 0, 16, 15, 16)));
    public static final RegistryObject<Block> PARTY_TABLE = BLOCKS.register("party_table",
            () -> new FacingBlock(decor(MapColor.SNOW, SoundType.WOOL), Block.box(0, 0, 0, 16, 12, 16)));
    public static final RegistryObject<Block> SECURITY_MONITOR = BLOCKS.register("security_monitor",
            () -> new SecurityMonitorBlock(decor(MapColor.COLOR_BLACK, SoundType.METAL), Block.box(2, 0, 2, 14, 14, 14)));
    public static final RegistryObject<Block> MUSIC_BOX = BLOCKS.register("music_box",
            () -> new MusicBoxBlock(decor(MapColor.WOOD, SoundType.WOOD), Block.box(3, 0, 3, 13, 9, 13)));

    public static final RegistryObject<Block> POWER_CORE = BLOCKS.register("power_core",
            () -> new PowerCoreBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.METAL).strength(3.0F).sound(SoundType.METAL)));
    public static final RegistryObject<Block> SECURITY_DOOR = BLOCKS.register("security_door",
            () -> new SecurityDoorBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.METAL).strength(5.0F).sound(SoundType.METAL).noOcclusion()));
    public static final RegistryObject<Block> PIRATE_CURTAIN = BLOCKS.register("pirate_cove_curtain",
            () -> new CurtainBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_PURPLE).strength(0.5F).sound(SoundType.WOOL).noOcclusion()));

    public static final RegistryObject<Block> FAZ_LIGHT = BLOCKS.register("faz_light",
            () -> new FazLightBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.METAL).strength(0.5F).sound(SoundType.GLASS).noOcclusion()
                    .lightLevel(state -> state.getValue(FazLightBlock.LIT) ? 15 : 0)));
    public static final RegistryObject<Block> LIGHT_SWITCH = BLOCKS.register("light_switch",
            () -> new LightSwitchBlock(decor(MapColor.METAL, SoundType.METAL), Block.box(4, 0, 4, 12, 10, 12)));
}
