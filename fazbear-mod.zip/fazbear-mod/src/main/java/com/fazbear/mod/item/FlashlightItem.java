package com.fazbear.mod.item;

import com.fazbear.mod.entity.AnimatronicEntity;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Point it at an animatronic to stun it for 5 seconds. Repair with redstone on an anvil. */
public class FlashlightItem extends Item {
    public FlashlightItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player.getCooldowns().isOnCooldown(this)) return InteractionResultHolder.pass(stack);

        if (!level.isClientSide) {
            Vec3 eye = player.getEyePosition();
            Vec3 look = player.getViewVector(1.0F);
            boolean hit = false;
            for (AnimatronicEntity e : level.getEntitiesOfClass(AnimatronicEntity.class, player.getBoundingBox().inflate(16.0D))) {
                Vec3 to = e.getEyePosition().subtract(eye);
                double d = to.length();
                if (d < 0.1D) continue;
                if (look.dot(to.scale(1.0D / d)) > 0.9D && player.hasLineOfSight(e)) {
                    e.stun(100);
                    e.addEffect(new MobEffectInstance(MobEffects.GLOWING, 100));
                    hit = true;
                }
            }
            level.playSound(null, player.blockPosition(), SoundEvents.LEVER_CLICK, SoundSource.PLAYERS, 1.0F, hit ? 1.4F : 0.8F);
            player.getCooldowns().addCooldown(this, hit ? 40 : 10);
            stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public boolean isValidRepairItem(ItemStack toRepair, ItemStack repair) {
        return repair.is(Items.REDSTONE);
    }
}
