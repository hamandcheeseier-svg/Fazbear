package com.fazbear.mod.data;

import net.minecraft.resources.ResourceLocation;

/** Parses GameData.CHARACTERS. Ids are 1-based (0 means "none / bare endo"). */
public final class Characters {
    public static final CharacterDef[] ALL;

    static {
        String[] raw = GameData.CHARACTERS;
        ALL = new CharacterDef[raw.length];
        for (int i = 0; i < raw.length; i++) {
            String[] f = raw[i].split("\\|", -1);
            String[] t = f[10].split(",");
            ResourceLocation[] tex = new ResourceLocation[t.length];
            for (int k = 0; k < t.length; k++) tex[k] = new ResourceLocation(t[k]);
            String[] s = f[11].split(";", -1);
            Box[][] slots = new Box[4][];
            for (int k = 0; k < 4; k++) slots[k] = Box.parseList(s[k]);
            ALL[i] = new CharacterDef(i + 1, f[0], f[1], f[2], Float.parseFloat(f[3]), Float.parseFloat(f[4]),
                    Float.parseFloat(f[5]), Integer.parseInt(f[6]), f[7], f[8], f[9], tex, slots);
        }
    }

    private Characters() {}

    /** @return the character, or null for id 0 / unknown */
    public static CharacterDef get(int id) {
        return id >= 1 && id <= ALL.length ? ALL[id - 1] : null;
    }

    public static String nameOf(int id) {
        CharacterDef d = get(id);
        return d == null ? "-" : d.name;
    }
}
