package com.fazbear.mod.registry;

import com.fazbear.mod.FazbearMod;
import com.fazbear.mod.Suits;
import com.fazbear.mod.data.CharacterDef;
import com.fazbear.mod.data.Characters;
import com.fazbear.mod.data.EndoTypeDef;
import com.fazbear.mod.data.EndoTypes;
import com.fazbear.mod.item.*;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayList;
import java.util.List;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, FazbearMod.MODID);

    /** ENDO_PARTS.get(type 0..).get(kind 0 leg, 1 torso, 2 arm, 3 head) */
    public static final List<List<RegistryObject<Item>>> ENDO_PARTS = new ArrayList<>();
    /** PIECES.get(character 0..).get(slot 0 head, 1 torso, 2 arms, 3 legs) */
    public static final List<List<RegistryObject<Item>>> PIECES = new ArrayList<>();
    public static final List<RegistryObject<Item>> FULL_SUITS = new ArrayList<>();
    public static final List<RegistryObject<Item>> PLUSHIES = new ArrayList<>();

    // ---- building blocks ----
    public static final RegistryObject<Item> ENDO_STAND = ITEMS.register("endo_stand",
            () -> new BlockItem(ModBlocks.ENDO_STAND.get(), new Item.Properties()));
    public static final RegistryObject<Item> CHECKER_TILE = ITEMS.register("checker_tile",
            () -> new BlockItem(ModBlocks.CHECKER_TILE.get(), new Item.Properties()));
    public static final RegistryObject<Item> PARTY_WALL = ITEMS.register("party_wall",
            () -> new BlockItem(ModBlocks.PARTY_WALL.get(), new Item.Properties()));
    public static final RegistryObject<Item> SHOW_STAGE = ITEMS.register("show_stage",
            () -> new BlockItem(ModBlocks.SHOW_STAGE.get(), new Item.Properties()));

    // ---- generated families ----
    static {
        for (EndoTypeDef t : EndoTypes.ALL) {
            List<RegistryObject<Item>> row = new ArrayList<>();
            for (int k = 0; k < 4; k++) {
                final int kind = k;
                final int type = t.id;
                row.add(ITEMS.register("endo_" + t.key + "_" + Suits.KIND_IDS[k],
                        () -> new EndoPartItem(kind, type, new Item.Properties())));
            }
            ENDO_PARTS.add(row);
        }
        for (CharacterDef c : Characters.ALL) {
            final int ch = c.id;
            List<RegistryObject<Item>> row = new ArrayList<>();
            for (int s = 0; s < 4; s++) {
                final int slot = s;
                row.add(ITEMS.register("suit_" + Suits.SLOT_IDS[s] + "_" + c.key,
                        () -> new SuitPieceItem(slot, ch, new Item.Properties())));
            }
            PIECES.add(row);
            FULL_SUITS.add(ITEMS.register("suit_full_" + c.key,
                    () -> new FullSuitItem(ch, new Item.Properties().stacksTo(1))));
            final int idx = c.id - 1;
            PLUSHIES.add(ITEMS.register("plush_" + c.key,
                    () -> new BlockItem(ModBlocks.PLUSHIES.get(idx).get(), new Item.Properties())));
        }
    }

    /** @param type 1-based endo type, kind 0 leg / 1 torso / 2 arm / 3 head */
    public static Item endoPart(int type, int kind) {
        int t = type < 1 ? 1 : type;
        return ENDO_PARTS.get(t - 1).get(kind).get();
    }

    // ---- tools & food ----
    public static final RegistryObject<Item> SERVICE_WRENCH = ITEMS.register("service_wrench",
            () -> new ServiceWrenchItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> PIZZA = ITEMS.register("pizza",
            () -> new Item(new Item.Properties().food(
                    new FoodProperties.Builder().nutrition(8).saturationMod(0.8F).build())));
    public static final RegistryObject<Item> PIZZERIA_BLUEPRINT = ITEMS.register("pizzeria_blueprint",
            () -> new PizzeriaBlueprintItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> FAZ_TOKEN = ITEMS.register("faz_token",
            () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> FAZ_KEY = ITEMS.register("faz_key",
            () -> new FazKeyItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> FLASHLIGHT = ITEMS.register("flashlight",
            () -> new FlashlightItem(new Item.Properties().durability(120)));

    // ---- decor & night-shift blocks ----
    public static final RegistryObject<Item> ARCADE_CABINET = ITEMS.register("arcade_cabinet",
            () -> new BlockItem(ModBlocks.ARCADE_CABINET.get(), new Item.Properties()));
    public static final RegistryObject<Item> PRIZE_COUNTER = ITEMS.register("prize_counter",
            () -> new BlockItem(ModBlocks.PRIZE_COUNTER.get(), new Item.Properties()));
    public static final RegistryObject<Item> PARTY_TABLE = ITEMS.register("party_table",
            () -> new BlockItem(ModBlocks.PARTY_TABLE.get(), new Item.Properties()));
    public static final RegistryObject<Item> SECURITY_MONITOR = ITEMS.register("security_monitor",
            () -> new BlockItem(ModBlocks.SECURITY_MONITOR.get(), new Item.Properties()));
    public static final RegistryObject<Item> MUSIC_BOX = ITEMS.register("music_box",
            () -> new BlockItem(ModBlocks.MUSIC_BOX.get(), new Item.Properties()));
    public static final RegistryObject<Item> POWER_CORE = ITEMS.register("power_core",
            () -> new BlockItem(ModBlocks.POWER_CORE.get(), new Item.Properties()));
    public static final RegistryObject<Item> SECURITY_DOOR = ITEMS.register("security_door",
            () -> new BlockItem(ModBlocks.SECURITY_DOOR.get(), new Item.Properties()));
    public static final RegistryObject<Item> PIRATE_CURTAIN = ITEMS.register("pirate_cove_curtain",
            () -> new BlockItem(ModBlocks.PIRATE_CURTAIN.get(), new Item.Properties()));

    public static final RegistryObject<Item> FAZ_LIGHT = ITEMS.register("faz_light",
            () -> new BlockItem(ModBlocks.FAZ_LIGHT.get(), new Item.Properties()));
    public static final RegistryObject<Item> LIGHT_SWITCH = ITEMS.register("light_switch",
            () -> new BlockItem(ModBlocks.LIGHT_SWITCH.get(), new Item.Properties()));
}
