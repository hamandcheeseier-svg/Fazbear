package com.fazbear.mod.registry;

import com.fazbear.mod.FazbearMod;
import com.fazbear.mod.block.EndoStandBlockEntity;
import com.fazbear.mod.block.LightSwitchBlockEntity;
import com.fazbear.mod.block.PowerCoreBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, FazbearMod.MODID);

    public static final RegistryObject<BlockEntityType<EndoStandBlockEntity>> ENDO_STAND =
            BLOCK_ENTITIES.register("endo_stand", () ->
                    BlockEntityType.Builder.of(EndoStandBlockEntity::new, ModBlocks.ENDO_STAND.get()).build(null));

    public static final RegistryObject<BlockEntityType<PowerCoreBlockEntity>> POWER_CORE =
            BLOCK_ENTITIES.register("power_core", () ->
                    BlockEntityType.Builder.of(PowerCoreBlockEntity::new, ModBlocks.POWER_CORE.get()).build(null));

    public static final RegistryObject<BlockEntityType<LightSwitchBlockEntity>> LIGHT_SWITCH =
            BLOCK_ENTITIES.register("light_switch", () ->
                    BlockEntityType.Builder.of(LightSwitchBlockEntity::new, ModBlocks.LIGHT_SWITCH.get()).build(null));
}
