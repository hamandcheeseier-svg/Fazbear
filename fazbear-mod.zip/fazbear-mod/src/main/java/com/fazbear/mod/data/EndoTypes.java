package com.fazbear.mod.data;

import net.minecraft.resources.ResourceLocation;

/** Parses GameData.ENDOS. Ids are 1-based (0 = part not installed). */
public final class EndoTypes {
    public static final EndoTypeDef[] ALL;

    static {
        String[] raw = GameData.ENDOS;
        ALL = new EndoTypeDef[raw.length];
        for (int i = 0; i < raw.length; i++) {
            String[] f = raw[i].split("\\|", -1);
            String[] t = f[5].split(",");
            ResourceLocation[] tex = new ResourceLocation[t.length];
            for (int k = 0; k < t.length; k++) tex[k] = new ResourceLocation(t[k]);
            String[] p = f[6].split(";", -1);
            Box[][] parts = new Box[6][];
            for (int k = 0; k < 6; k++) parts[k] = Box.parseList(p[k]);
            ALL[i] = new EndoTypeDef(i + 1, f[0], f[1], Float.parseFloat(f[2]), Float.parseFloat(f[3]),
                    Float.parseFloat(f[4]), tex, parts);
        }
    }

    private EndoTypes() {}

    public static EndoTypeDef get(int id) {
        return id >= 1 && id <= ALL.length ? ALL[id - 1] : null;
    }
}
