package com.fazbear.mod.world;

import com.fazbear.mod.block.EndoStandBlock;
import com.fazbear.mod.block.EndoStandBlockEntity;
import com.fazbear.mod.block.FacingBlock;
import com.fazbear.mod.block.FazLightBlock;
import com.fazbear.mod.block.LightSwitchBlock;
import com.fazbear.mod.block.LightSwitchBlockEntity;
import com.fazbear.mod.block.PlateBlock;
import com.fazbear.mod.data.Characters;
import com.fazbear.mod.registry.ModBlocks;
import com.fazbear.mod.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;

/**
 * Builds a full pizzeria:
 *  - dining room: checkered floor, tables, party tables, arcade row, prize counter, ceiling lights on a wall switch
 *  - show stage with 3 empty endo stands, plushies and a music box
 *  - Pirate Cove (right of the stage) with a sleeping, fully assembled Foxy
 *  - right annex: Parts &amp; Service (every suit piece in chests, endo parts, 2 practice stands)
 *  - left annex : Security Office (monitor, power core, security doors wired to a switch, tools)
 * Coordinates: a = left/right (centered, +a is to the right), b = depth forward, y = height.
 */
public final class PizzeriaBuilder {
    private static final int HALF_W = 10;
    private static final int DEPTH = 15;

    private final Level level;
    private final BlockPos origin;
    private final Direction f;   // forward
    private final Direction r;   // right

    private PizzeriaBuilder(Level level, BlockPos origin, Direction forward) {
        this.level = level;
        this.origin = origin;
        this.f = forward;
        this.r = forward.getClockWise();
    }

    public static void build(Level level, BlockPos origin, Direction forward) {
        new PizzeriaBuilder(level, origin, forward).run();
    }

    private BlockPos at(int a, int b, int y) {
        return origin.relative(r, a).relative(f, b).above(y);
    }

    private void set(int a, int b, int y, BlockState s) {
        level.setBlock(at(a, b, y), s, 3);
    }

    private void facing(int a, int b, int y, Block block, Direction dir) {
        set(a, b, y, block.defaultBlockState().setValue(FacingBlock.FACING, dir));
    }

    private void stand(int a, int b, int y) {
        BlockState lower = ModBlocks.ENDO_STAND.get().defaultBlockState()
                .setValue(EndoStandBlock.FACING, f.getOpposite());
        set(a, b, y, lower);
        set(a, b, y + 1, lower.setValue(EndoStandBlock.HALF, DoubleBlockHalf.UPPER));
    }

    /** A finished, sleeping animatronic: Endo 01 under a full suit of one character. */
    private void sleepingStand(int a, int b, int y, String characterKey) {
        stand(a, b, y);
        int id = 1;
        for (var d : Characters.ALL) if (d.key.equals(characterKey)) id = d.id;
        if (level.getBlockEntity(at(a, b, y)) instanceof EndoStandBlockEntity be) {
            be.stage = 6;
            for (int i = 0; i < 6; i++) be.endo[i] = 1;
            for (int i = 0; i < 4; i++) be.suit[i] = id;
            be.sync();
        }
    }

    private void chest(int a, int b, Direction dir, Item[] items, int[] counts) {
        BlockPos pos = at(a, b, 1);
        level.setBlock(pos, Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, dir), 3);
        if (level.getBlockEntity(pos) instanceof ChestBlockEntity c) {
            for (int i = 0; i < items.length; i++) c.setItem(i, new ItemStack(items[i], counts[i]));
        }
    }

    private LightSwitchBlockEntity placeSwitch(int a, int b, int y, Direction dir) {
        set(a, b, y, ModBlocks.LIGHT_SWITCH.get().defaultBlockState().setValue(FacingBlock.FACING, dir));
        return level.getBlockEntity(at(a, b, y)) instanceof LightSwitchBlockEntity be ? be : null;
    }

    private void run() {
        BlockState air = Blocks.AIR.defaultBlockState();
        BlockState tile = ModBlocks.CHECKER_TILE.get().defaultBlockState();
        BlockState wall = ModBlocks.PARTY_WALL.get().defaultBlockState();
        BlockState stage = ModBlocks.SHOW_STAGE.get().defaultBlockState();
        BlockState roof = Blocks.DARK_OAK_PLANKS.defaultBlockState();
        BlockState lamp = Blocks.GLOWSTONE.defaultBlockState();
        BlockState spruce = Blocks.SPRUCE_PLANKS.defaultBlockState();
        BlockState fazLight = ModBlocks.FAZ_LIGHT.get().defaultBlockState();

        // ---- main shell
        for (int a = -HALF_W; a <= HALF_W; a++) {
            for (int b = 1; b <= DEPTH; b++) {
                boolean edge = Math.abs(a) == HALF_W || b == 1 || b == DEPTH;
                set(a, b, 0, tile);
                for (int y = 1; y <= 5; y++) set(a, b, y, edge ? wall : air);
                set(a, b, 6, roof);
            }
        }
        for (int a = -1; a <= 1; a++) for (int y = 1; y <= 3; y++) set(a, 1, y, air);
        for (int a = 4; a <= 7; a++) for (int y = 2; y <= 3; y++) {
            set(a, 1, y, Blocks.GLASS.defaultBlockState());
            set(-a, 1, y, Blocks.GLASS.defaultBlockState());
        }

        // ---- ceiling lights (linked to a wall switch by the entrance) + a few glowstone safety lamps
        LightSwitchBlockEntity diningSwitch = placeSwitch(2, 2, 1, f.getOpposite());
        for (int a : new int[]{-6, -2, 2, 6}) {
            for (int b : new int[]{3, 6, 9}) {
                set(a, b, 5, fazLight);
                if (diningSwitch != null) diningSwitch.links.add(at(a, b, 5));
            }
        }
        if (diningSwitch != null) diningSwitch.setChanged();
        for (int a : new int[]{-10, 0, 10}) set(a, 8, 6, lamp);

        // ---- show stage (left of centre) + Pirate Cove (right)
        for (int a = -8; a <= 8; a++) for (int y = 1; y <= 5; y++) set(a, DEPTH, y, Blocks.RED_WOOL.defaultBlockState());
        for (int a = -8; a <= 2; a++) for (int b = 11; b <= DEPTH - 1; b++) set(a, b, 1, stage);
        for (int a : new int[]{-6, -3, 0}) stand(a, 13, 2);
        int[] plushA = {-7, -5, -3, -1, 1};
        for (int i = 0; i < 5; i++) facing(plushA[i], 11, 2, ModBlocks.PLUSHIES.get(i).get(), f.getOpposite());
        facing(2, 11, 2, ModBlocks.MUSIC_BOX.get(), f.getOpposite());

        for (int a = 4; a <= 9; a++) for (int b = 11; b <= DEPTH - 1; b++) set(a, b, 0, spruce);
        for (int b = 11; b <= DEPTH - 1; b++) for (int y = 1; y <= 4; y++) set(4, b, y, spruce);
        for (int a = 5; a <= 9; a++) {
            set(a, 11, 4, spruce);
            for (int y = 1; y <= 3; y++) {
                set(a, 11, y, ModBlocks.PIRATE_CURTAIN.get().defaultBlockState().setValue(PlateBlock.FACING, f));
            }
        }
        sleepingStand(7, 13, 1, "foxy");

        // ---- dining room
        for (int a : new int[]{-7, -3, 3, 7}) {
            for (int b : new int[]{4, 8}) {
                set(a, b, 1, Blocks.SPRUCE_FENCE.defaultBlockState());
                set(a, b, 2, Blocks.SMOOTH_QUARTZ_SLAB.defaultBlockState());
            }
        }
        facing(-5, 6, 1, ModBlocks.PARTY_TABLE.get(), f);
        facing(5, 6, 1, ModBlocks.PARTY_TABLE.get(), f);
        for (int b : new int[]{3, 4, 8, 9}) facing(-9, b, 1, ModBlocks.ARCADE_CABINET.get(), r);
        facing(9, 9, 1, ModBlocks.PRIZE_COUNTER.get(), r.getOpposite());

        // ---- annexes (right = Parts & Service, left = Security Office)
        BlockState annexFloor = Blocks.POLISHED_ANDESITE.defaultBlockState();
        BlockState annexWall = Blocks.STONE_BRICKS.defaultBlockState();
        for (int side : new int[]{1, -1}) {
            for (int k = HALF_W + 1; k <= HALF_W + 8; k++) {
                int a = side * k;
                for (int b = 2; b <= 10; b++) {
                    boolean edge = k == HALF_W + 8 || b == 2 || b == 10;
                    set(a, b, 0, annexFloor);
                    for (int y = 1; y <= 4; y++) set(a, b, y, edge ? annexWall : air);
                    set(a, b, 5, roof);
                }
            }
            for (int b = 5; b <= 6; b++) for (int y = 1; y <= 3; y++) set(side * HALF_W, b, y, air);
        }

        // right annex: 7 chests along the back wall hold EVERY suit piece (6 characters = 24 pieces per chest)
        int perChest = 6;
        for (int c = 0; c < 7; c++) {
            BlockPos pos = at(HALF_W + 7, 3 + c, 1);
            level.setBlock(pos, Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, r.getOpposite()), 3);
            if (level.getBlockEntity(pos) instanceof ChestBlockEntity ch) {
                int slot = 0;
                for (int i = c * perChest; i < Math.min(Characters.ALL.length, (c + 1) * perChest); i++) {
                    for (int s = 0; s < 4; s++) ch.setItem(slot++, new ItemStack(ModItems.PIECES.get(i).get(s).get()));
                }
            }
        }
        // endo parts of all three types
        BlockPos partsPos = at(HALF_W + 4, 9, 1);
        level.setBlock(partsPos, Blocks.CHEST.defaultBlockState().setValue(ChestBlock.FACING, f.getOpposite()), 3);
        if (level.getBlockEntity(partsPos) instanceof ChestBlockEntity ch) {
            int slot = 0;
            for (int type = 1; type <= 3; type++) {
                ch.setItem(slot++, new ItemStack(ModItems.endoPart(type, 0), 4));
                ch.setItem(slot++, new ItemStack(ModItems.endoPart(type, 1), 2));
                ch.setItem(slot++, new ItemStack(ModItems.endoPart(type, 2), 4));
                ch.setItem(slot++, new ItemStack(ModItems.endoPart(type, 3), 2));
            }
            ch.setItem(slot++, new ItemStack(ModItems.SERVICE_WRENCH.get()));
            ch.setItem(slot, new ItemStack(ModItems.PIZZA.get(), 8));
        }
        stand(HALF_W + 3, 6, 1);
        stand(HALF_W + 5, 6, 1);

        // ---- Security Office (left annex)
        int officeA = -(HALF_W + 6);
        for (int b = 5; b <= 7; b++) set(officeA, b, 1, Blocks.DARK_OAK_PLANKS.defaultBlockState());
        facing(officeA, 6, 2, ModBlocks.SECURITY_MONITOR.get(), r);
        set(-(HALF_W + 7), 6, 1, ModBlocks.POWER_CORE.get().defaultBlockState());

        // two security doors across the doorway, wired to a switch inside the office
        LightSwitchBlockEntity doorSwitch = placeSwitch(-(HALF_W + 1), 4, 1, r);
        for (int b = 5; b <= 6; b++) {
            for (int y = 1; y <= 3; y++) {
                set(-HALF_W, b, y, ModBlocks.SECURITY_DOOR.get().defaultBlockState()
                        .setValue(PlateBlock.FACING, r).setValue(PlateBlock.OPEN, true));
                if (doorSwitch != null) doorSwitch.links.add(at(-HALF_W, b, y));
            }
        }
        if (doorSwitch != null) doorSwitch.setChanged();
        // an office lamp on its own switch
        LightSwitchBlockEntity lampSwitch = placeSwitch(-(HALF_W + 1), 8, 1, r);
        set(-(HALF_W + 4), 6, 4, fazLight);
        set(-(HALF_W + 4), 7, 4, fazLight);
        if (lampSwitch != null) {
            lampSwitch.links.add(at(-(HALF_W + 4), 6, 4));
            lampSwitch.links.add(at(-(HALF_W + 4), 7, 4));
            lampSwitch.setChanged();
        }

        chest(-(HALF_W + 7), 4, r,
                new Item[]{ModItems.FLASHLIGHT.get(), ModItems.FLASHLIGHT.get(), ModItems.FAZ_KEY.get(),
                        ModItems.FAZ_KEY.get(), Items.REDSTONE, Items.REDSTONE_BLOCK, ModItems.FAZ_TOKEN.get(),
                        ModItems.SERVICE_WRENCH.get()},
                new int[]{1, 1, 1, 1, 32, 8, 10, 1});
        chest(-(HALF_W + 7), 8, r,
                new Item[]{ModItems.PIZZA.get(), ModItems.MUSIC_BOX.get(), ModItems.MUSIC_BOX.get(),
                        ModItems.FAZ_LIGHT.get(), ModItems.LIGHT_SWITCH.get(), ModItems.SECURITY_DOOR.get()},
                new int[]{16, 1, 1, 8, 2, 4});
    }
}
