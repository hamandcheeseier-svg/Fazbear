package com.fazbear.mod.data;

import net.minecraft.resources.ResourceLocation;

/** One animatronic character: look (per suit slot), stats and sound. Generated data lives in GameData. */
public final class CharacterDef {
    public static final int ABILITY_NONE = 0, ABILITY_SPRINT = 1, ABILITY_BURN = 2, ABILITY_SHOCK = 3;
    /** texture role indices used by Box.tex */
    public static final int BODY = 0, ACCENT = 1, BELLY = 2, EYE = 3, DARK = 4, METAL = 5, DETAIL = 6;

    public final int id;
    public final String key, name, game;
    public final float speedMod, damageMod, healthMod;
    public final int ability;
    public final String lead, harmony, rhythm;
    public final ResourceLocation[] tex;
    /** head, torso, arms, legs */
    public final Box[][] slots;

    public CharacterDef(int id, String key, String name, String game, float speedMod, float damageMod, float healthMod,
                        int ability, String lead, String harmony, String rhythm, ResourceLocation[] tex, Box[][] slots) {
        this.id = id; this.key = key; this.name = name; this.game = game;
        this.speedMod = speedMod; this.damageMod = damageMod; this.healthMod = healthMod;
        this.ability = ability; this.lead = lead; this.harmony = harmony; this.rhythm = rhythm;
        this.tex = tex; this.slots = slots;
    }
}
