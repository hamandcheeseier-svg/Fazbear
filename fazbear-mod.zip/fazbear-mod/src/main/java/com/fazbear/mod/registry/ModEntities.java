package com.fazbear.mod.registry;

import com.fazbear.mod.FazbearMod;
import com.fazbear.mod.entity.AnimatronicEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, FazbearMod.MODID);

    public static final RegistryObject<EntityType<AnimatronicEntity>> ANIMATRONIC = ENTITIES.register("animatronic",
            () -> EntityType.Builder.<AnimatronicEntity>of(AnimatronicEntity::new, MobCategory.MISC)
                    .sized(0.9F, 2.0F).clientTrackingRange(10).build("animatronic"));
}
