package com.fazbear.mod.data;

/** A textured box in model pixels (16 = 1 block, figure is 32 tall). tex = texture role index, side = -1 left / 1 right / 0 none. */
public final class Box {
    public final float x1, y1, z1, x2, y2, z2;
    public final int tex;
    public final int side;

    public Box(float x1, float y1, float z1, float x2, float y2, float z2, int tex, int side) {
        this.x1 = x1; this.y1 = y1; this.z1 = z1;
        this.x2 = x2; this.y2 = y2; this.z2 = z2;
        this.tex = tex; this.side = side;
    }

    /** "x1,y1,z1,x2,y2,z2,tex,side/x1,..." */
    public static Box[] parseList(String s) {
        if (s.isEmpty()) return new Box[0];
        String[] boxes = s.split("/");
        Box[] out = new Box[boxes.length];
        for (int i = 0; i < boxes.length; i++) {
            String[] v = boxes[i].split(",");
            out[i] = new Box(Float.parseFloat(v[0]), Float.parseFloat(v[1]), Float.parseFloat(v[2]),
                    Float.parseFloat(v[3]), Float.parseFloat(v[4]), Float.parseFloat(v[5]),
                    Integer.parseInt(v[6]), Integer.parseInt(v[7]));
        }
        return out;
    }
}
