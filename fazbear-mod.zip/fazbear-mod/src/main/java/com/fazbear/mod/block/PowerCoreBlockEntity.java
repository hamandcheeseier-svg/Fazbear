package com.fazbear.mod.block;

import com.fazbear.mod.entity.AnimatronicEntity;
import com.fazbear.mod.power.PowerNetwork;
import com.fazbear.mod.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

/** Holds the night's power. Closed Security Doors drain it. At zero: POWER OUT and animatronics go hunting. */
public class PowerCoreBlockEntity extends BlockEntity {
    public static final int MAX = 3000;
    public int charge = MAX;
    private int tickCounter = 0;

    public PowerCoreBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.POWER_CORE.get(), pos, state);
    }

    public int percent() {
        return (int) Math.ceil(charge * 100.0 / MAX);
    }

    public void add(int amount) {
        charge = Math.min(MAX, charge + amount);
        setChanged();
        updateLevelProperty();
    }

    /** @return true if there was power to take (the core may hit zero doing so) */
    public boolean consume(int amount) {
        if (charge <= 0) return false;
        charge = Math.max(0, charge - amount);
        setChanged();
        updateLevelProperty();
        if (charge == 0) powerOut();
        return true;
    }

    private void updateLevelProperty() {
        if (level == null || level.isClientSide) return;
        int bracket = charge <= 0 ? 0 : Math.min(4, 1 + charge * 4 / (MAX + 1));
        BlockState st = getBlockState();
        if (st.hasProperty(PowerCoreBlock.LEVEL) && st.getValue(PowerCoreBlock.LEVEL) != bracket) {
            level.setBlock(worldPosition, st.setValue(PowerCoreBlock.LEVEL, bracket), 3);
        }
    }

    private void powerOut() {
        if (level == null || level.isClientSide) return;
        level.playSound(null, worldPosition, SoundEvents.BEACON_DEACTIVATE, SoundSource.BLOCKS, 3.0F, 0.5F);
        AABB area = new AABB(worldPosition).inflate(48.0D);
        for (Player p : level.getEntitiesOfClass(Player.class, area)) {
            p.displayClientMessage(Component.literal("\u00a74\u00a7lPOWER OUT"), true);
        }
        for (AnimatronicEntity e : level.getEntitiesOfClass(AnimatronicEntity.class, area)) e.powerOut(600);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, PowerCoreBlockEntity be) {
        if (++be.tickCounter >= 20) {
            be.tickCounter = 0;
            be.consume(1); // baseline drain: 1 unit per second
        }
    }

    @Override
    public void onLoad() {
        super.onLoad();
        if (level != null) PowerNetwork.register(level, worldPosition);
    }

    @Override
    public void setRemoved() {
        super.setRemoved();
        if (level != null) PowerNetwork.unregister(level, worldPosition);
    }

    @Override
    public void onChunkUnloaded() {
        super.onChunkUnloaded();
        if (level != null) PowerNetwork.unregister(level, worldPosition);
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putInt("Charge", charge);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        charge = tag.contains("Charge") ? tag.getInt("Charge") : MAX;
    }
}
