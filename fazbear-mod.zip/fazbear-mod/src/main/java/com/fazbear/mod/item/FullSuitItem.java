package com.fazbear.mod.item;

import net.minecraft.world.item.Item;

/** A whole matching suit, crafted from the 4 pieces. Fits every slot at once on a finished endoskeleton. */
public class FullSuitItem extends Item {
    private final int character;

    public FullSuitItem(int character, Properties props) {
        super(props);
        this.character = character;
    }

    public int getCharacter() { return character; }
}
