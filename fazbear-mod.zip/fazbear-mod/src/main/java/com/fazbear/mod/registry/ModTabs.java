package com.fazbear.mod.registry;

import com.fazbear.mod.FazbearMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

import java.util.HashSet;
import java.util.Set;

public class ModTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, FazbearMod.MODID);

    private static Set<Item> suitItems() {
        Set<Item> set = new HashSet<>();
        for (var row : ModItems.PIECES) for (var o : row) set.add(o.get());
        for (var o : ModItems.FULL_SUITS) set.add(o.get());
        for (var o : ModItems.PLUSHIES) set.add(o.get());
        return set;
    }

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.fazbear"))
                    .icon(() -> new ItemStack(ModItems.endoPart(1, 3)))
                    .displayItems((params, out) -> {
                        Set<Item> suits = suitItems();
                        ModItems.ITEMS.getEntries().forEach(i -> {
                            if (!suits.contains(i.get())) out.accept(i.get());
                        });
                    })
                    .build());

    public static final RegistryObject<CreativeModeTab> SUITS = TABS.register("suits",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.fazbear.suits"))
                    .icon(() -> new ItemStack(ModItems.FULL_SUITS.get(0).get()))
                    .displayItems((params, out) -> {
                        for (var o : ModItems.FULL_SUITS) out.accept(o.get());
                        for (var row : ModItems.PIECES) for (var o : row) out.accept(o.get());
                        for (var o : ModItems.PLUSHIES) out.accept(o.get());
                    })
                    .build());
}
