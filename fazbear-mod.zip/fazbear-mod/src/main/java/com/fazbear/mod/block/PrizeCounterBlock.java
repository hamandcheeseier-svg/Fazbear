package com.fazbear.mod.block;

import com.fazbear.mod.Performance;
import com.fazbear.mod.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Trade 5 Faz Tokens for a random prize. */
public class PrizeCounterBlock extends FacingBlock {
    public PrizeCounterBlock(Properties props, VoxelShape shape) {
        super(props, shape);
    }

    @Override
    protected InteractionResult interact(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        if (!held.is(ModItems.FAZ_TOKEN.get())) {
            if (!level.isClientSide && hand == InteractionHand.MAIN_HAND) {
                player.displayClientMessage(Component.literal("Prize Counter: hand over 5 Faz Tokens for a prize!"), true);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (held.getCount() < 5) {
            if (!level.isClientSide) player.displayClientMessage(Component.literal("You need 5 Faz Tokens."), true);
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (!level.isClientSide) {
            if (!player.getAbilities().instabuild) held.shrink(5);
            RandomSource r = level.random;
            ItemStack prize = switch (r.nextInt(8)) {
                case 0, 1, 2 -> new ItemStack(ModItems.PLUSHIES.get(r.nextInt(com.fazbear.mod.data.Characters.ALL.length)).get());
                case 3, 4 -> new ItemStack(ModItems.PIZZA.get(), 4);
                case 5 -> new ItemStack(ModItems.FLASHLIGHT.get());
                case 6 -> new ItemStack(ModItems.SERVICE_WRENCH.get());
                default -> new ItemStack(ModItems.PIECES.get(r.nextInt(com.fazbear.mod.data.Characters.ALL.length)).get(r.nextInt(4)).get());
            };
            if (!player.getInventory().add(prize)) player.drop(prize, false);
            Performance.note(level, pos.getX() + 0.5, pos.getY() + 1, pos.getZ() + 0.5, "chime", 1.5F, 1.5F);
            player.displayClientMessage(Component.literal("Prize: ").append(prize.getHoverName()), true);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
