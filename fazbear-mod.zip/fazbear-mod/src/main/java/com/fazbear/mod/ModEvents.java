package com.fazbear.mod;

import com.fazbear.mod.entity.AnimatronicEntity;
import com.fazbear.mod.registry.ModEntities;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = FazbearMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModEvents {
    @SubscribeEvent
    public static void attributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.ANIMATRONIC.get(), AnimatronicEntity.createAttributes().build());
    }
}
