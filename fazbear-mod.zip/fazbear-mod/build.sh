#!/bin/sh
echo "Building Fazbear Animatronics (needs Java 17)..."
./gradlew build && echo "Done! Your jar is in build/libs/"
