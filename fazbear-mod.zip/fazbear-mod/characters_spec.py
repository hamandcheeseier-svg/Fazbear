"""Single source of truth for every character and endo type.
Generates box data (GameData.java) plus the info the asset generator needs (colours, recipes, names)."""

BODY, ACC, BELLY, EYE, DARK, METAL, DET = range(7)

def B(x1, y1, z1, x2, y2, z2, t, s=0):
    return (x1, y1, z1, x2, y2, z2, t, s)

def shz(boxes, dz):
    return [(a, b, c + dz, d, e, f + dz, t, s) for (a, b, c, d, e, f, t, s) in boxes]

# ------------------------------------------------------------------ bases (name -> (boxes, front-z shift for features))
HEAD_BASE = {
    "std":   ([B(4,24,4,12,30,12,BODY)], 0),
    "wide":  ([B(3,24,4,13,30,12,BODY)], 0),
    "tall":  ([B(4,24,4,12,31,12,BODY)], 0),
    "small": ([B(5,24,5,11,29,11,BODY)], 1),
    "mask":  ([B(4,24,4,12,30,12,ACC)], 0),
}
EYES = {
    "socket": [B(5,26,3.6,8,29,3.9,DARK), B(8,26,3.6,11,29,3.9,DARK), B(6,27,3.9,7,28,4.1,EYE), B(9,27,3.9,10,28,4.1,EYE)],
    "std":   [B(5.5,26.5,3.6,7.5,28.5,4,EYE), B(8.5,26.5,3.6,10.5,28.5,4,EYE)],
    "big":   [B(5,26,3.6,8,29,4,EYE), B(8,26,3.6,11,29,4,EYE)],
    "small": [B(6,27,3.6,7.5,28.5,4,EYE), B(8.5,27,3.6,10,28.5,4,EYE)],
}
TORSO_BASE = {
    "std":     ([B(3,13,4,13,24,12,BODY), B(5,14,3.6,11,21,4,BELLY)], 0),
    "heavy":   ([B(2,13,3,14,24,13,BODY), B(4,14,2.6,12,22,3,BELLY)], -1),
    "slim":    ([B(4,13,5,12,24,11,BODY), B(6,15,4.6,10,21,5,BELLY)], 1),
    "pear":    ([B(4,19,5,12,24,11,BODY), B(2,13,3,14,19,13,BODY), B(4,14,2.6,12,19,3,BELLY)], 1),
}
TORSO_BASE["shirt"] = ([B(4,13,5,12,24,11,BELLY), B(3.9,14.5,4.8,12.1,16,11.1,ACC), B(3.9,18,4.8,12.1,19.5,11.1,ACC),
                        B(3.9,21.5,4.8,12.1,23,11.1,ACC)], 1)
TORSO_BASE["tutu"] = ([B(4,14,5,12,24,11,BODY), B(6,15,4.6,10,21,5,BELLY)], 1)
ARMS_BASE = {
    "thin":     [B(1,6,6.5,2.5,24,9.5,BODY,-1), B(13.5,6,6.5,15,24,9.5,BODY,1)],
    "std":      [B(0,14,5,3,24,11,BODY,-1), B(13,14,5,16,24,11,BODY,1)],
    "slim":     [B(1,14,6,3,24,10,BODY,-1), B(13,14,6,15,24,10,BODY,1)],
    "heavy":    [B(-1,14,4,3,24,12,BODY,-1), B(13,14,4,17,24,12,BODY,1)],
    "long":     [B(0,8,5.5,3,24,10.5,BODY,-1), B(13,8,5.5,16,24,10.5,BODY,1)],
    "no_right": [B(0,14,5,3,24,11,BODY,-1), B(13,14,6,15,23,9,METAL,1)],
    "no_left":  [B(1,14,6,4,23,9,METAL,-1), B(13,14,5,16,24,11,BODY,1)],
}
LEGS_BASE = {
    "thin":         [B(4.5,1,6.5,6.5,13,9.5,BODY,-1), B(9.5,1,6.5,11.5,13,9.5,BODY,1)],
    "pants":        [B(4,1,6,7,13,10,ACC,-1), B(9,1,6,12,13,10,ACC,1)],
    "std":          [B(3,1,5,7,13,11,BODY,-1), B(9,1,5,13,13,11,BODY,1)],
    "slim":         [B(4,1,6,7,13,10,BODY,-1), B(9,1,6,12,13,10,BODY,1)],
    "heavy":        [B(2,1,4,7,13,12,BODY,-1), B(9,1,4,14,13,12,BODY,1)],
    "exposed_shin": [B(3,6,5,7,13,11,BODY,-1), B(3.5,1,5.5,6.5,6,10.5,METAL,-1),
                     B(9,6,5,13,13,11,BODY,1), B(9.5,1,5.5,12.5,6,10.5,METAL,1)],
}

# ------------------------------------------------------------------ features
FEAT_HEAD = {
    "bear_ears":        [B(3,27,6,4,30,9,BODY), B(12,27,6,13,30,9,BODY)],
    "bear_ears_big":    [B(2.5,28,5.5,4.5,31,9.5,BODY), B(11.5,28,5.5,13.5,31,9.5,BODY)],
    "bear_ear_left_only": [B(3,27,6,4,30,9,BODY)],
    "rabbit_ears":      [B(5,30,6,7,37,8,BODY), B(9,30,6,11,37,8,BODY)],
    "rabbit_ear_torn":  [B(5,30,6,7,37,8,BODY), B(9,30,6,11,33,8,BODY)],
    "rabbit_inner":     [B(5.4,30,5.8,6.6,35,6.2,BELLY), B(9.4,30,5.8,10.6,35,6.2,BELLY)],
    "rabbit_one":       [B(5,30,6,7,36,8,BODY)],
    "lop_ears":         [B(2,25,6,4,31,9,BODY), B(12,25,6,14,31,9,BODY)],
    "fox_ears":         [B(4,30,6,6,34,8,BODY), B(10,30,6,12,34,8,BODY)],
    "fox_ears_acc":     [B(4,30,6,6,34,8,ACC), B(10,30,6,12,34,8,ACC)],
    "fox_ear_one":      [B(4,30,6,6,34,8,BODY)],
    "muzzle":           [B(5.5,24.5,3.4,10.5,26.5,4,BELLY)],
    "fox_snout":        [B(5.5,24.5,2.5,10.5,26,4,BODY)],
    "wolf_snout":       [B(5,24.5,2,11,26.5,4,BODY), B(7,26,1.8,9,27,2.2,DARK)],
    "gator_snout":      [B(4.5,24,0.5,11.5,26,4,BODY), B(4.5,26,0.8,11.5,27,4,BODY), B(4.7,25.8,0.5,11.3,26.2,3,DET)],
    "beak":             [B(6,25,2.5,10,26.5,4,ACC)],
    "beak_open":        [B(6,25.5,2.5,10,26.5,4,ACC), B(6,23.5,2.5,10,24.5,4.5,ACC)],
    "tuft":             [B(7,30,7,9,31.5,9,BODY)],
    "top_hat":          [B(4,30,4,12,30.8,12,DARK), B(5.2,30.8,5.2,10.8,34,10.8,DARK)],
    "top_hat_small":    [B(4.5,30,4.5,11.5,30.6,11.5,DARK), B(5.5,30.6,5.5,10.5,33,10.5,DARK)],
    "top_hat_acc":      [B(4,30,4,12,30.8,12,ACC), B(5.2,30.8,5.2,10.8,34,10.8,ACC)],
    "hat_band":         [B(5,30.8,5,11,31.6,11,DET)],
    "cap":              [B(4,30,4,12,31,12,ACC), B(4,29.5,2.5,12,30.5,4,DARK)],
    "propeller":        [B(7.5,31,7.5,8.5,32,8.5,DARK), B(5,31,7.7,11,31.6,8.3,ACC)],
    "eyepatch":         [B(5.5,27.5,3.5,7.5,29,3.6,DARK)],
    "cheeks":           [B(4.3,25,3.6,5.8,26.2,4,ACC), B(10.2,25,3.6,11.7,26.2,4,ACC)],
    "cheeks_det":       [B(4.3,25,3.6,5.8,26.2,4,DET), B(10.2,25,3.6,11.7,26.2,4,DET)],
    "pigtails":         [B(1.5,24,6,4,30,9,ACC), B(12,24,6,14.5,30,9,ACC)],
    "tears":            [B(5.7,24.5,3.55,6.3,26.5,4,DARK), B(9.7,24.5,3.55,10.3,26.5,4,DARK), B(6,24.5,3.55,10,25,4,DARK)],
    "maw":              [B(4.5,23.2,3.4,11.5,26,4.2,DARK), B(5,25,3.3,6,26.2,4.5,DET), B(6.8,25,3.3,7.8,26.2,4.5,DET),
                          B(8.2,25,3.3,9.2,26.2,4.5,DET), B(10,25,3.3,11,26.2,4.5,DET),
                          B(5.5,23.2,3.3,6.5,24.4,4.5,DET), B(7.5,23.2,3.3,8.5,24.4,4.5,DET), B(9.5,23.2,3.3,10.5,24.4,4.5,DET)],
    "fox_snout_open":   [B(5.5,25.5,2.3,10.5,26.7,4,BODY), B(6,23.3,2.8,10,24.5,4.4,BODY), B(6,24.5,3,10,25.5,4,DARK),
                          B(6.3,24.4,3,7.2,25.5,3.6,DET), B(8.8,24.4,3,9.7,25.5,3.6,DET)],
    "endo_face":        [B(5,24.5,3.7,11,29.5,4.1,METAL), B(5.8,26.5,3.9,7.3,28,4.3,DET), B(8.7,26.5,3.9,10.2,28,4.3,DET)],
    "mohawk":           [B(7,30,5,9,32.5,11,ACC), B(7.3,32.5,6,8.7,34,10,ACC)],
    "tall_hat_acc":     [B(5,30,5,11,34,11,ACC)],
    "jaw_teeth":        [B(5,24,3.4,6.5,25.3,4,DET), B(7.2,24,3.4,8.8,25.3,4,DET), B(9.5,24,3.4,11,25.3,4,DET)],
    "exposed_jaw":      [B(5,24,3.9,11,25.8,4.2,METAL)],
    "torn_face":        [B(7,27,3.9,10,29.5,4.2,METAL)],
    "horns":            [B(4,30,6,6,34,8,ACC), B(10,30,6,12,34,8,ACC), B(5.5,33,6,7.5,36,8,ACC), B(8.5,33,6,10.5,36,8,ACC)],
    "rays":             [B(7,30,7,9,32,9,ACC), B(2,26,7,4,28,9,ACC), B(12,26,7,14,28,9,ACC), B(3,29,7,5,31,9,ACC), B(11,29,7,13,31,9,ACC)],
    "headphones":       [B(3,26,5.5,4.5,30,10.5,ACC), B(11.5,26,5.5,13,30,10.5,ACC), B(3,29.5,6,13,30.8,10,ACC)],
    "bun":              [B(6,30,6,10,32,10,ACC)],
    "mask_band":        [B(5,26,3.8,11,29.2,4.2,ACC)],
    "wires":            [B(3,24,3,4.5,31.5,5,ACC), B(11.5,24,3,13,31.5,5,ACC), B(7.3,30,4,8.7,32,6,ACC), B(5,30,7,6.2,32,9,ACC)],
    "shades":           [B(5,27,3.8,11,28.7,4.3,ACC)],
    "lashes":           [B(5.3,28.5,3.5,7.8,29.3,4,DARK), B(8.2,28.5,3.5,10.7,29.3,4,DARK)],
}
FEAT_TORSO = {
    "bow_dark":   [B(6,23,3.6,10,24.5,4,DARK)],
    "bow_acc":    [B(6,23,3.6,10,24.5,4,ACC)],
    "bow_det":    [B(6,23,3.6,10,24.5,4,DET)],
    "bib":        [B(3.6,14,3.55,12.4,23.5,4.05,BELLY)],
    "tail_fox":   [B(6.5,12,12,9.5,19,16,BODY), B(7,19,13,9,21,16.5,BELLY)],
    "tail_wolf":  [B(7,12,12,9,20,16.5,BODY)],
    "torn_chest": [B(5,15,3.7,11,22,4.1,METAL)],
    "ribs":       [B(4.5,15,3.7,11.5,16,4.2,METAL), B(4.5,17.5,3.7,11.5,18.5,4.2,METAL), B(4.5,20,3.7,11.5,21,4.2,METAL)],
    "dress":      [B(2,10,3,14,15,13,ACC)],
    "skirt":      [B(1,8,1,15,11,15,ACC), B(2.5,11,2.5,13.5,14,13.5,ACC), B(4,14,4,12,15,12,BELLY)],
    "star":       [B(7,17,3.5,9,20,4,ACC), B(6,18,3.5,10,19,4,ACC)],
    "ruff":       [B(2,22,3,14,24.5,13,ACC)],
    "wires":      [B(4,14,3.7,5,23,4.2,ACC), B(7.5,14,3.7,8.5,23,4.2,ACC), B(11,14,3.7,12,23,4.2,ACC), B(5.5,16,3.5,6.2,22,4.4,DET), B(9.5,16,3.5,10.2,22,4.4,DET)],
    "vest":       [B(3.5,14,3.7,6.5,23,4.1,ACC), B(9.5,14,3.7,12.5,23,4.1,ACC)],
    "speaker":    [B(5,15,3.5,11,21,4,DARK), B(6,16,3.4,10,20,3.6,ACC)],
}
FEAT_ARMS = {
    "hook":       [B(14,11,7.5,15,14,8.5,METAL,1)],
    "claws":      [B(0.2,10,5.5,0.8,14,6,DET,-1), B(1.2,10,7.5,1.8,14,8,DET,-1), B(2.2,10,9.5,2.8,14,10,DET,-1),
                   B(13.2,10,5.5,13.8,14,6,DET,1), B(14.2,10,7.5,14.8,14,8,DET,1), B(15.2,10,9.5,15.8,14,10,DET,1)],
    "claws_left": [B(0.2,10,5.5,0.8,14,6,DET,-1), B(1.2,10,7.5,1.8,14,8,DET,-1), B(2.2,10,9.5,2.8,14,10,DET,-1)],
    "gloves":     [B(0,12,5,3,14,11,ACC,-1), B(13,12,5,16,14,11,ACC,1)],
    "mic":        [B(14.5,11,7,15.5,15,8,METAL,1), B(14,15,6.5,16,17,8.5,DARK,1)],
    "guitar":     [B(-3,8,6,1,16,7.5,ACC,-1), B(-1.5,16,6.3,-0.5,27,7.2,DARK,-1), B(-2,27,6.2,0,29,7.3,DARK,-1)],
    "cupcake":    [B(13,13,6,16,13.6,10,METAL,1), B(13.5,13.6,7,15.5,15.2,9,ACC,1), B(13.8,15.2,7.3,15.2,16.3,8.7,BELLY,1)],
    "balloon":    [B(14.4,14,8,14.8,30,8.4,DARK,1), B(12,30,6,17,36,11,ACC,1)],
    "big_claws":  [B(-0.3,7,5.2,0.8,14,6.3,DET,-1), B(0.8,6.5,6.8,1.9,14,7.9,DET,-1), B(1.8,6.5,8.4,2.9,14,9.5,DET,-1), B(2.3,7,9.9,3.4,14,11,DET,-1),
                   B(12.6,7,5.2,13.7,14,6.3,DET,1), B(13.7,6.5,6.8,14.8,14,7.9,DET,1), B(14.7,6.5,8.4,15.8,14,9.5,DET,1), B(15.2,7,9.9,16.3,14,11,DET,1)],
    "endo_hands": [B(0,10.5,5.5,3,14,10.5,METAL,-1), B(13,10.5,5.5,16,14,10.5,METAL,1)],
}
FEAT_LEGS = {
    "boots": [B(3,1,4.5,7,3,11.5,ACC,-1), B(9,1,4.5,13,3,11.5,ACC,1)],
}

# ------------------------------------------------------------------ characters
CHARS = []
INST_LEAD = ["bass", "guitar", "flute", "banjo", "bell", "chime", "harp", "bit", "pling", "xylophone"]
INST_HARM = ["harp", "pling", "guitar", "chime", "bell", "flute", "banjo", "xylophone"]
INST_RHY = ["basedrum", "hat", "snare", "cow_bell", "iron_xylophone", "bit"]

def C(key, name, game, body, acc, belly, eye, wool, head=(), torso=(), arms=(), legs=(),
      hb="std", eb="std", tb="std", ab="std", lb="std", st=(0, 0, 0), ability=0, det="white_concrete", inst=None):
    i = len(CHARS)
    if inst is None:
        inst = (INST_LEAD[(i * 3) % len(INST_LEAD)], INST_HARM[(i * 5) % len(INST_HARM)], INST_RHY[i % len(INST_RHY)])
    hboxes, hdz = HEAD_BASE[hb]
    head_b = list(hboxes) + shz(EYES[eb], hdz)
    for f in head: head_b += shz(FEAT_HEAD[f], hdz)
    tboxes, tdz = TORSO_BASE[tb]
    torso_b = list(tboxes)
    for f in torso: torso_b += shz(FEAT_TORSO[f], tdz)
    arms_b = list(ARMS_BASE[ab])
    for f in arms: arms_b += FEAT_ARMS[f]
    legs_b = list(LEGS_BASE[lb])
    for f in legs: legs_b += FEAT_LEGS[f]
    CHARS.append(dict(
        key=key, name=name, game=game, wool=wool, st=st, ability=ability, inst=inst,
        head_feats=list(head), torso_feats=list(torso), arms_feats=list(arms), legs_feats=list(legs),
        tex=[body, acc, belly, eye, "black_concrete", "iron_block", det],
        slots=[head_b, torso_b, arms_b, legs_b], hb=hb))

# ---- FNaF 1
C("freddy", "Freddy", "FNaF 1", "brown_wool", "black_wool", "orange_terracotta", "light_blue_concrete", "brown_wool",
  head=("bear_ears", "muzzle", "top_hat"), torso=("bow_dark",), arms=("mic",), inst=("bass", "harp", "basedrum"))
C("bonnie", "Bonnie", "FNaF 1", "purple_wool", "red_wool", "magenta_wool", "white_concrete", "purple_wool",
  head=("rabbit_ears", "muzzle"), torso=("bow_acc",), arms=("guitar",), inst=("guitar", "pling", "hat"))
C("chica", "Chica", "FNaF 1", "yellow_wool", "orange_wool", "white_wool", "magenta_concrete", "yellow_wool",
  head=("beak", "tuft"), torso=("bib",), arms=("cupcake",), inst=("flute", "harp", "snare"))
C("foxy", "Foxy", "FNaF 1", "red_wool", "gray_wool", "orange_wool", "yellow_concrete", "red_wool",
  head=("fox_snout_open", "fox_ears", "eyepatch"), torso=("torn_chest", "tail_fox"), arms=("hook",), lb="exposed_shin",
  st=(0.15, 0, 0), ability=1, det="white_concrete", inst=("banjo", "guitar", "cow_bell"))
C("golden_freddy", "Golden Freddy", "FNaF 1", "gold_block", "black_concrete", "honeycomb_block", "white_concrete", "orange_wool",
  head=("bear_ears", "muzzle", "top_hat_acc"), torso=("bow_dark",), eb="socket", st=(0, 0, -5), inst=("bell", "chime", "hat"))
# ---- FNaF 2
C("toy_freddy", "Toy Freddy", "FNaF 2", "orange_concrete", "blue_concrete", "white_terracotta", "light_blue_concrete", "orange_wool",
  head=("bear_ears", "muzzle", "cheeks", "top_hat_small"), torso=("bow_acc",), arms=("mic",), tb="slim", ab="slim", lb="slim",
  st=(0.1, 0, 0), inst=("bell", "harp", "hat"))
C("toy_bonnie", "Toy Bonnie", "FNaF 2", "light_blue_concrete", "red_concrete", "white_concrete", "lime_concrete", "light_blue_wool",
  head=("rabbit_ears", "muzzle", "cheeks"), torso=("bow_acc",), arms=("guitar",), tb="slim", ab="slim", lb="slim",
  st=(0.1, 0, 0), inst=("guitar", "pling", "hat"))
C("toy_chica", "Toy Chica", "FNaF 2", "yellow_concrete", "magenta_concrete", "white_concrete", "purple_concrete", "yellow_wool",
  head=("beak", "tuft", "cheeks"), torso=("bib",), arms=("cupcake",), tb="slim", ab="slim", lb="slim", st=(0.1, 0, 0),
  inst=("flute", "bell", "snare"))
C("mangle", "Mangle", "FNaF 2", "white_concrete", "pink_concrete", "light_gray_concrete", "yellow_concrete", "white_wool",
  head=("fox_snout_open", "fox_ears_acc", "torn_face"), torso=("torn_chest", "tail_fox"), arms=("claws",), ab="long", lb="slim", tb="slim",
  st=(0.15, 1.5, -5), ability=1, inst=("bit", "pling", "hat"))
C("balloon_boy", "Balloon Boy", "FNaF 2", "white_terracotta", "blue_concrete", "red_concrete", "light_blue_concrete", "cyan_wool",
  head=("cap", "propeller"), arms=("balloon",), hb="wide", eb="big", tb="shirt", ab="slim", lb="pants", st=(0.05, -2, -10),
  inst=("chime", "bell", "hat"))
C("puppet", "The Puppet", "FNaF 2", "black_concrete", "white_concrete", "white_concrete", "black_concrete", "black_wool",
  head=("tears", "cheeks_det"), arms=("gloves",), hb="mask", tb="slim", ab="thin", lb="thin", st=(0.05, 0, -5), det="red_concrete",
  inst=("chime", "harp", "hat"))
C("withered_freddy", "Withered Freddy", "FNaF 2", "brown_terracotta", "black_terracotta", "terracotta", "white_concrete", "brown_wool",
  head=("bear_ear_left_only", "exposed_jaw", "top_hat"), torso=("bow_dark", "torn_chest"), eb="socket", ab="no_right",
  st=(0, 2, -10), inst=("bass", "banjo", "basedrum"))
C("withered_bonnie", "Withered Bonnie", "FNaF 2", "purple_terracotta", "red_terracotta", "magenta_terracotta", "white_concrete", "purple_wool",
  head=("rabbit_one", "endo_face"), torso=("bow_acc", "torn_chest"), arms=("endo_hands",), ab="no_left", eb="small",
  st=(0, 2, -10), det="red_concrete", inst=("guitar", "banjo", "hat"))
C("withered_chica", "Withered Chica", "FNaF 2", "yellow_terracotta", "orange_terracotta", "white_terracotta", "magenta_concrete", "yellow_wool",
  head=("beak_open", "tuft"), torso=("torn_chest",), arms=("endo_hands",), eb="socket", st=(0, 2, -10), inst=("flute", "banjo", "snare"))
C("withered_foxy", "Withered Foxy", "FNaF 2", "red_terracotta", "gray_terracotta", "orange_terracotta", "yellow_concrete", "red_wool",
  head=("fox_snout_open", "fox_ear_one", "eyepatch"), torso=("torn_chest", "tail_fox"), arms=("hook",), lb="exposed_shin",
  st=(0.2, 2, -10), ability=1, inst=("banjo", "guitar", "cow_bell"))
C("withered_golden_freddy", "Withered Golden Freddy", "FNaF 2", "raw_gold_block", "black_concrete", "yellow_terracotta", "white_concrete", "orange_wool",
  head=("bear_ears", "exposed_jaw", "top_hat_acc"), torso=("torn_chest",), eb="socket", ab="no_right", st=(0, 2, -10),
  inst=("bell", "chime", "hat"))
# ---- FNaF 3
C("springtrap", "Springtrap", "FNaF 3", "lime_terracotta", "yellow_terracotta", "black_concrete", "white_concrete", "green_wool",
  head=("rabbit_ear_torn", "exposed_jaw", "torn_face"), torso=("ribs",), arms=("claws",), eb="socket", st=(0, 2, 10),
  inst=("bass", "guitar", "snare"))
C("spring_bonnie", "Spring Bonnie", "FNaF 3", "yellow_concrete", "purple_concrete", "yellow_terracotta", "white_concrete", "yellow_wool",
  head=("rabbit_ears", "muzzle"), torso=("bow_acc",), inst=("flute", "guitar", "hat"))
# ---- FNaF 4
C("nightmare_freddy", "Nightmare Freddy", "FNaF 4", "brown_concrete", "black_concrete", "orange_terracotta", "white_concrete", "brown_wool",
  head=("bear_ears_big", "maw", "top_hat"), torso=("bow_dark",), arms=("big_claws",), tb="heavy", ab="heavy", eb="socket",
  st=(-0.05, 3, 15), inst=("bass", "bass", "basedrum"))
C("nightmare_bonnie", "Nightmare Bonnie", "FNaF 4", "blue_terracotta", "black_concrete", "blue_concrete", "white_concrete", "blue_wool",
  head=("rabbit_ears", "maw"), torso=("bow_acc",), arms=("big_claws",), tb="heavy", ab="heavy", eb="socket", st=(0, 3, 10),
  inst=("guitar", "bass", "snare"))
C("nightmare_chica", "Nightmare Chica", "FNaF 4", "yellow_terracotta", "orange_terracotta", "white_terracotta", "white_concrete", "yellow_wool",
  head=("beak_open", "tuft", "maw"), torso=("bib",), arms=("big_claws",), tb="heavy", ab="heavy", eb="socket", st=(0, 3, 5),
  inst=("flute", "bass", "snare"))
C("nightmare_foxy", "Nightmare Foxy", "FNaF 4", "red_concrete", "gray_concrete", "orange_terracotta", "white_concrete", "red_wool",
  head=("fox_snout_open", "fox_ears", "maw", "eyepatch"), torso=("torn_chest", "tail_fox"), arms=("hook", "claws_left"),
  lb="exposed_shin", eb="socket", st=(0.2, 3, 5), ability=1, inst=("banjo", "bass", "cow_bell"))
C("nightmare_fredbear", "Nightmare Fredbear", "FNaF 4", "yellow_terracotta", "purple_concrete", "orange_terracotta", "white_concrete", "yellow_wool",
  head=("bear_ears_big", "maw", "top_hat_acc"), torso=("bow_acc",), arms=("big_claws",), tb="heavy", ab="heavy", eb="socket",
  st=(-0.05, 4, 20), inst=("bass", "chime", "basedrum"))
C("nightmare", "Nightmare", "FNaF 4", "black_concrete", "purple_concrete", "black_concrete", "white_concrete", "black_wool",
  head=("bear_ears_big", "maw", "top_hat_acc"), torso=("bow_acc",), arms=("big_claws",), tb="heavy", ab="heavy", eb="socket",
  st=(-0.05, 4, 15), inst=("bass", "bass", "basedrum"))
C("plushtrap", "Plushtrap", "FNaF 4", "green_wool", "red_wool", "lime_concrete", "white_concrete", "lime_wool",
  head=("rabbit_ears", "muzzle"), torso=("bow_acc",), hb="small", eb="small", tb="slim", ab="slim", lb="slim",
  st=(0.3, -3, -20), ability=1, inst=("bit", "pling", "hat"))
C("fredbear", "Fredbear", "FNaF 4", "yellow_concrete", "purple_wool", "yellow_terracotta", "white_concrete", "yellow_wool",
  head=("bear_ears", "muzzle", "top_hat_acc"), torso=("bow_acc",), arms=("mic",), inst=("bass", "guitar", "snare"))
# ---- Sister Location
C("circus_baby", "Circus Baby", "Sister Location", "white_concrete", "red_concrete", "red_concrete", "lime_concrete", "white_wool",
  head=("pigtails", "cheeks"), torso=("dress",), arms=("gloves",), legs=("boots",), ab="slim", lb="slim",
  st=(0, 1, 0), ability=3, inst=("harp", "bell", "hat"))
C("ballora", "Ballora", "Sister Location", "purple_concrete", "pink_concrete", "magenta_concrete", "magenta_concrete", "purple_wool",
  head=("bun", "mask_band"), torso=("skirt",), arms=("gloves",), tb="slim", ab="slim", lb="thin", st=(0.1, 0, 0),
  inst=("harp", "bell", "hat"))
C("funtime_freddy", "Funtime Freddy", "Sister Location", "white_concrete", "pink_concrete", "white_concrete", "light_blue_concrete", "pink_wool",
  head=("bear_ears", "muzzle", "cheeks", "top_hat_acc"), torso=("bow_det",), arms=("gloves",), tb="heavy", st=(0, 0, 15),
  det="blue_concrete", inst=("bell", "chime", "basedrum"))
C("funtime_foxy", "Funtime Foxy", "Sister Location", "white_concrete", "pink_concrete", "pink_concrete", "yellow_concrete", "white_wool",
  head=("fox_snout", "fox_ears_acc", "eyepatch", "cheeks"), torso=("tail_fox",), arms=("hook",), lb="slim", st=(0.15, 0, 0),
  ability=1, inst=("banjo", "pling", "cow_bell"))
C("ennard", "Ennard", "Sister Location", "gray_concrete", "red_concrete", "black_concrete", "white_concrete", "gray_wool",
  head=("wires",), torso=("wires",), arms=("big_claws",), eb="big", tb="heavy", ab="long", st=(0, 2, 5), ability=3, det="lime_concrete",
  inst=("bit", "xylophone", "snare"))
# ---- Pizzeria Simulator
C("scrap_baby", "Scrap Baby", "Pizzeria Simulator", "exposed_copper", "oxidized_copper", "copper_block", "lime_concrete", "orange_wool",
  head=("pigtails", "torn_face"), torso=("torn_chest", "dress"), arms=("big_claws",), ab="long", lb="slim", st=(0.05, 2, 0),
  inst=("bit", "harp", "hat"))
C("molten_freddy", "Molten Freddy", "Pizzeria Simulator", "magma", "black_concrete", "orange_concrete", "white_concrete", "orange_wool",
  head=("bear_ears", "muzzle", "top_hat"), torso=("ribs", "wires"), arms=("big_claws",), ab="long", eb="socket",
  st=(0, 2, 5), ability=2, det="orange_concrete", inst=("bass", "pling", "basedrum"))
C("lefty", "Lefty", "Pizzeria Simulator", "black_concrete", "pink_concrete", "black_concrete", "white_concrete", "black_wool",
  head=("bear_ears", "muzzle", "cheeks"), torso=("bow_acc",), st=(0, 1, 5), inst=("bass", "bell", "snare"))
C("scraptrap", "Scraptrap", "Pizzeria Simulator", "lime_terracotta", "yellow_terracotta", "black_concrete", "white_concrete", "lime_wool",
  head=("rabbit_ear_torn", "exposed_jaw", "torn_face"), torso=("ribs", "torn_chest"), arms=("big_claws",), eb="socket", st=(0, 3, 15),
  inst=("bass", "guitar", "snare"))
# ---- Security Breach
C("glamrock_freddy", "Glamrock Freddy", "Security Breach", "brown_concrete", "yellow_concrete", "light_blue_concrete", "light_blue_concrete", "brown_wool",
  head=("bear_ears", "muzzle", "shades"), torso=("star",), arms=("mic",), st=(0.05, 0, 5), inst=("guitar", "bass", "snare"))
C("glamrock_chica", "Glamrock Chica", "Security Breach", "yellow_concrete", "magenta_concrete", "pink_concrete", "lime_concrete", "yellow_wool",
  head=("beak", "tuft", "lashes"), torso=("star",), st=(0.05, 0, 0), inst=("flute", "pling", "hat"))
C("roxanne_wolf", "Roxanne Wolf", "Security Breach", "cyan_concrete", "red_concrete", "light_gray_concrete", "yellow_concrete", "cyan_wool",
  head=("wolf_snout", "fox_ears", "shades", "mohawk"), torso=("star", "tail_wolf"), arms=("big_claws",), st=(0.2, 1, 0), ability=1,
  inst=("banjo", "guitar", "cow_bell"))
C("montgomery_gator", "Montgomery Gator", "Security Breach", "lime_concrete", "purple_concrete", "yellow_concrete", "yellow_concrete", "lime_wool",
  head=("gator_snout", "shades"), torso=("vest",), arms=("big_claws",), tb="heavy", ab="heavy", st=(-0.1, 3, 20),
  inst=("bass", "banjo", "basedrum"))
C("sun", "Sunrise", "Security Breach", "yellow_concrete", "orange_concrete", "yellow_wool", "light_blue_concrete", "yellow_wool",
  head=("rays",), torso=("ruff",), arms=("gloves",), tb="slim", ab="slim", lb="slim", st=(0.05, 0, 0),
  inst=("chime", "harp", "hat"))
C("moon", "Moondrop", "Security Breach", "blue_concrete", "purple_concrete", "black_concrete", "yellow_concrete", "blue_wool",
  head=("horns",), torso=("ruff",), arms=("claws",), tb="slim", ab="slim", lb="slim", st=(0.1, 2, 0),
  inst=("chime", "bass", "hat"))
C("dj_music_man", "DJ Music Man", "Security Breach", "magenta_concrete", "yellow_concrete", "purple_concrete", "lime_concrete", "magenta_wool",
  head=("headphones",), torso=("speaker",), tb="heavy", ab="long", st=(0, 2, 5), ability=3, inst=("bit", "xylophone", "basedrum"))

# ------------------------------------------------------------------ endo types
M_, D_, C_, E_ = 0, 1, 2, 3
ENDOS = [
    dict(key="01", name="Endo 01", st=(0, 0, 0),
         tex=["iron_block", "black_concrete", "redstone_block", "white_concrete"],
         main="minecraft:iron_ingot", rgb=(190, 195, 200),
         parts=[
             [B(4,1,6,7,13,9,M_,-1), B(3.5,6,5.5,7.5,7.5,9.5,D_,-1)],
             [B(9,1,6,12,13,9,M_,1), B(8.5,6,5.5,12.5,7.5,9.5,D_,1)],
             [B(4,13,5,12,23,11,M_), B(6,15,4.5,10,20,5,C_), B(7,22,7,9,23,9,D_)],
             [B(1,14,6,4,23,9,M_,-1), B(0.7,18,5.7,4.3,19.3,9.3,D_,-1)],
             [B(12,14,6,15,23,9,M_,1), B(11.7,18,5.7,15.3,19.3,9.3,D_,1)],
             [B(5,23,5,11,30,11,M_), B(6,26,4.5,7.5,27.5,5,E_), B(8.5,26,4.5,10,27.5,5,E_)],
         ]),
    dict(key="02", name="Endo 02", st=(0.1, 0, -5),
         tex=["polished_deepslate", "black_concrete", "redstone_lamp_on", "lime_concrete"],
         main="minecraft:copper_ingot", rgb=(90, 90, 100),
         parts=[
             [B(4.5,1,6.5,6.5,13,8.5,M_,-1), B(4,6,6,7,7.5,9,D_,-1)],
             [B(9.5,1,6.5,11.5,13,8.5,M_,1), B(9,6,6,12,7.5,9,D_,1)],
             [B(5,13,5.5,11,23,10.5,M_), B(6.5,16,5,9.5,21,5.5,C_), B(5.5,14,5,10.5,14.8,5.5,D_), B(5.5,22,5,10.5,22.8,5.5,D_)],
             [B(2,14,6.5,4,23,8.5,M_,-1), B(1.7,18,6.2,4.3,19,8.8,D_,-1)],
             [B(12,14,6.5,14,23,8.5,M_,1), B(11.7,18,6.2,14.3,19,8.8,D_,1)],
             [B(5.5,23,5.5,10.5,29.5,10.5,M_), B(6,26,5,7.5,27.5,5.5,E_), B(8.5,26,5,10,27.5,5.5,E_), B(7.5,29.5,7.5,8.5,31.5,8.5,D_)],
         ]),
    dict(key="yenndo", name="Yenndo", st=(-0.05, 1.5, 10),
         tex=["exposed_copper", "coal_block", "redstone_block", "white_concrete"],
         main="minecraft:raw_iron", rgb=(170, 115, 90),
         parts=[
             [B(3.5,1,5.5,7.5,13,9.5,M_,-1), B(3,1,5,8,3,10,D_,-1)],
             [B(8.5,1,5.5,12.5,13,9.5,M_,1), B(8,1,5,13,3,10,D_,1)],
             [B(3,13,4.5,13,23,11.5,M_), B(6,15,4,10,20,4.5,C_), B(6,22,6,10,23,10,D_)],
             [B(0.5,14,5.5,3.5,23,9.5,M_,-1), B(0,13,5,4,15,10,D_,-1)],
             [B(12.5,14,5.5,15.5,23,9.5,M_,1), B(12,13,5,16,15,10,D_,1)],
             [B(4,23,4,12,31,12,M_), B(5,26.5,3.5,7.5,29,4,E_), B(8.5,26.5,3.5,11,29,4,E_), B(6,24,3.5,10,25,4,D_)],
         ]),
]

# ------------------------------------------------------------------ Java data
def _num(v):
    return ("%g" % v)

def _boxes(bs):
    return "/".join(",".join([_num(x) for x in b[:6]] + [str(b[6]), str(b[7])]) for b in bs)

def java_data():
    rows = []
    for c in CHARS:
        tex = ",".join("minecraft:block/" + t for t in c["tex"])
        slots = ";".join(_boxes(s) for s in c["slots"])
        rows.append("|".join([c["key"], c["name"], c["game"], _num(c["st"][0]), _num(c["st"][1]), _num(c["st"][2]),
                              str(c["ability"]), c["inst"][0], c["inst"][1], c["inst"][2], tex, slots]))
    endo_rows = []
    for e in ENDOS:
        tex = ",".join("minecraft:block/" + t for t in e["tex"])
        parts = ";".join(_boxes(p) for p in e["parts"])
        endo_rows.append("|".join([e["key"], e["name"], _num(e["st"][0]), _num(e["st"][1]), _num(e["st"][2]), tex, parts]))
    def arr(name, items):
        body = ",\n".join('        "' + r + '"' for r in items)
        return "    public static final String[] %s = {\n%s\n    };\n" % (name, body)
    return ("package com.fazbear.mod.data;\n\n/** GENERATED by gen_assets.py from characters_spec.py - do not edit by hand. */\n"
            "public final class GameData {\n" + arr("CHARACTERS", rows) + "\n" + arr("ENDOS", endo_rows) +
            "\n    private GameData() {}\n}\n")
