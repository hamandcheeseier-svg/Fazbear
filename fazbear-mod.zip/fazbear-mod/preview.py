"""Renders every character / endo type from characters_spec.py to PNG contact sheets so the models can be inspected.
usage: python3 preview.py [yaw_degrees]"""
import math, sys
from PIL import Image, ImageDraw, ImageFont
import characters_spec as sp

WORDS = [("light_blue",(60,170,220)),("light_gray",(150,150,145)),("white",(235,235,235)),("orange",(235,130,30)),
         ("magenta",(190,70,180)),("yellow",(240,200,40)),("lime",(110,190,30)),("pink",(240,140,170)),
         ("gray",(75,80,85)),("cyan",(20,140,150)),("purple",(120,40,170)),("blue",(45,55,160)),("brown",(110,70,40)),
         ("green",(85,110,35)),("red",(170,40,40)),("black",(20,20,25))]
SPECIAL = {"gold_block":(245,200,60),"raw_gold_block":(200,150,50),"honeycomb_block":(230,170,40),"iron_block":(200,200,205),
           "magma":(190,70,20),"exposed_copper":(160,115,95),"oxidized_copper":(80,170,140),"copper_block":(190,110,70),
           "coal_block":(25,25,25),"polished_deepslate":(70,70,75),"redstone_block":(180,20,10),"terracotta":(150,95,70),
           "redstone_lamp_on":(250,190,90)}
TERRA = {"white":(209,178,161),"orange":(162,84,38),"magenta":(149,88,108),"light_blue":(113,108,137),"yellow":(186,133,35),
         "lime":(103,117,53),"pink":(162,78,79),"gray":(57,42,35),"light_gray":(135,107,98),"cyan":(86,91,91),
         "purple":(118,70,86),"blue":(74,59,91),"brown":(77,51,35),"green":(76,83,42),"red":(143,61,46),"black":(37,22,16)}
def rgb(name):
    if name in SPECIAL: return SPECIAL[name]
    c = (128,128,128)
    for word, col in WORDS:
        if name.startswith(word): c = col; break
    if name.endswith("_terracotta"): c = TERRA.get(name[:-11], c)
    return c

FACES = [  # (normal, 4 corners as (xsel,ysel,zsel) with 0=min 1=max)
    ((0,0,-1), [(1,0,0),(0,0,0),(0,1,0),(1,1,0)]),
    ((0,0,1),  [(0,0,1),(1,0,1),(1,1,1),(0,1,1)]),
    ((1,0,0),  [(1,0,1),(1,0,0),(1,1,0),(1,1,1)]),
    ((-1,0,0), [(0,0,0),(0,0,1),(0,1,1),(0,1,0)]),
    ((0,1,0),  [(0,1,1),(1,1,1),(1,1,0),(0,1,0)]),
    ((0,-1,0), [(0,0,0),(1,0,0),(1,0,1),(0,0,1)]),
]
SHADE = {(0,0,-1):0.95,(0,0,1):0.7,(1,0,0):0.8,(-1,0,0):0.8,(0,1,0):1.0,(0,-1,0):0.5}

def render(boxes, texcols, size=(230, 330), yaw=28, pitch=20, scale=8.5, glow=False):
    img = Image.new("RGB", size, (38, 40, 48))
    d = ImageDraw.Draw(img)
    cy, sy_ = math.cos(math.radians(yaw)), math.sin(math.radians(yaw))
    cp, sp_ = math.cos(math.radians(pitch)), math.sin(math.radians(pitch))
    def rot(x, y, z):
        x -= 8; z -= 8
        xr = x*cy - z*sy_
        zr = x*sy_ + z*cy_ if False else x*sy_ + z*cy
        return xr, y, zr
    polys = []
    for (x1,y1,z1,x2,y2,z2,t,side) in boxes:
        lo = (min(x1,x2),min(y1,y2),min(z1,z2)); hi = (max(x1,x2),max(y1,y2),max(z1,z2))
        col = texcols[t]
        for normal, corners in FACES:
            nx, ny, nz = normal
            nxr = nx*cy - nz*sy_; nzr = nx*sy_ + nz*cy
            # camera looks along +z (after yaw), pitched down; visible if normal faces camera
            vis = -(nzr*cp) + ny*sp_ * 1.0
            if vis <= 0.02: continue
            pts = []; depth = 0
            for (a,b,c) in corners:
                x = hi[0] if a else lo[0]; y = hi[1] if b else lo[1]; z = hi[2] if c else lo[2]
                xr, yr, zr = rot(x, y, z)
                sx = size[0]/2 + xr*scale
                sy = size[1] - 20 - (yr*cp + zr*sp_)*scale
                pts.append((sx, sy)); depth += zr*cp - yr*sp_
            f = SHADE[normal]
            polys.append((depth/4, pts, tuple(min(255,int(v*f)) for v in col)))
    polys.sort(key=lambda p: -p[0])
    for _, pts, col in polys:
        d.polygon(pts, fill=col, outline=(15,15,18))
    return img

def sheet(items, path, cols=4, cell=(230, 350)):
    rows = (len(items)+cols-1)//cols
    out = Image.new("RGB", (cols*cell[0], rows*cell[1]), (38,40,48))
    for i, (label, img) in enumerate(items):
        x, y = (i%cols)*cell[0], (i//cols)*cell[1]
        out.paste(img, (x, y))
        ImageDraw.Draw(out).text((x+6, y+cell[1]-30), label, fill=(255,255,255))
    out.save(path)

def char_boxes(c):
    b = []
    for s in c["slots"]: b += s
    return b

def main():
    yaw = float(sys.argv[1]) if len(sys.argv) > 1 else 28
    items = []
    for c in sp.CHARS:
        cols = [rgb(t) for t in c["tex"]]
        items.append((f'{c["name"]} ({c["game"]})', render(char_boxes(c), cols, yaw=yaw), c))
    import os
    os.makedirs("/tmp/prev", exist_ok=True)
    for n in range(0, len(items), 8):
        chunk = items[n:n+8]
        sheet([(a, b) for a, b, _ in chunk], f"/tmp/prev/chars_{n//8+1}.png")
    # endo types
    e_items = []
    for e in sp.ENDOS:
        cols = [rgb(t) for t in e["tex"]]
        boxes = [b for p in e["parts"] for b in p] + [(2,0,2,14,1,14,1,0)]
        e_items.append((e["name"], render(boxes, cols, yaw=yaw)))
    sheet(e_items, "/tmp/prev/endos.png", cols=3)
    print("sheets:", len(items)//8 + (1 if len(items)%8 else 0), "+ endos")

main()
