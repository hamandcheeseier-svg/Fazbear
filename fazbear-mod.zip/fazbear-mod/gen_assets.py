"""Generates GameData.java + every JSON (blockstates, models, recipes, loot, advancements, lang) and pixel-art
textures for the mod from characters_spec.py. Run: python3 gen_assets.py   (needs Pillow)"""
import json, os, shutil, random
from PIL import Image, ImageDraw
import characters_spec as spec
from characters_spec import CHARS, ENDOS

MOD = "fazbear"
RES = "src/main/resources"
A = f"{RES}/assets/{MOD}"
D = f"{RES}/data/{MOD}"
for d in (A, D):
    shutil.rmtree(d, ignore_errors=True)

def w(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as fh:
        json.dump(data, fh, indent=1)

# ------------------------------------------------------------------ java data
with open("src/main/java/com/fazbear/mod/data/GameData.java", "w") as fh:
    fh.write(spec.java_data())

FACES = ["north", "east", "south", "west", "up", "down"]
def box(a, b, tex, rot=None):
    e = {"from": a, "to": b, "faces": {f: {"texture": "#" + tex} for f in FACES}}
    if rot: e["rotation"] = rot
    return e
mc = lambda n: f"minecraft:block/{n}"
ROT = (("north", 0), ("east", 90), ("south", 180), ("west", 270))

def loot(n):
    w(f"{D}/loot_tables/blocks/{n}.json", {"type": "minecraft:block", "pools": [{"rolls": 1,
        "entries": [{"type": "minecraft:item", "name": f"{MOD}:{n}"}],
        "conditions": [{"condition": "minecraft:survives_explosion"}]}]})

def item_model_block(n, parent):
    w(f"{A}/models/item/{n}.json", {"parent": f"{MOD}:block/{parent}"})

# ------------------------------------------------------------------ colours for icons
WORDS = [("light_blue",(60,170,220)),("light_gray",(150,150,145)),("white",(235,235,235)),("orange",(235,130,30)),
         ("magenta",(190,70,180)),("yellow",(240,200,40)),("lime",(110,190,30)),("pink",(240,140,170)),
         ("gray",(75,80,85)),("cyan",(20,140,150)),("purple",(120,40,170)),("blue",(45,55,160)),("brown",(110,70,40)),
         ("green",(85,110,35)),("red",(170,40,40)),("black",(20,20,25))]
SPECIAL = {"gold_block":(245,200,60),"raw_gold_block":(200,150,50),"honeycomb_block":(230,170,40),"iron_block":(200,200,205),
           "magma":(190,70,20),"exposed_copper":(160,115,95),"oxidized_copper":(80,170,140),"copper_block":(190,110,70),
           "coal_block":(25,25,25),"polished_deepslate":(70,70,75),"redstone_block":(180,20,10),"terracotta":(150,95,70)}
TERRA = {"white":(209,178,161),"orange":(162,84,38),"magenta":(149,88,108),"light_blue":(113,108,137),"yellow":(186,133,35),
         "lime":(103,117,53),"pink":(162,78,79),"gray":(57,42,35),"light_gray":(135,107,98),"cyan":(86,91,91),
         "purple":(118,70,86),"blue":(74,59,91),"brown":(77,51,35),"green":(76,83,42),"red":(143,61,46),"black":(37,22,16)}
def rgb(name):
    if name in SPECIAL: c = SPECIAL[name]
    else:
        c = (128, 128, 128)
        for word, col in WORDS:
            if name.startswith(word): c = col; break
        if name.endswith("_terracotta"): c = TERRA.get(name[:-11], c)
    return (c[0], c[1], c[2], 255)

def shade(c, f):
    return (min(255, int(c[0]*f)), min(255, int(c[1]*f)), min(255, int(c[2]*f)), 255)

def px(path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    return img, ImageDraw.Draw(img)

def icon(name, rects):
    path = f"{A}/textures/item/{name}.png"
    img, d = px(path)
    for x1, y1, x2, y2, c in rects:
        d.rectangle([x1, y1, x2, y2], fill=c)
    img.save(path)
    w(f"{A}/models/item/{name}.json", {"parent": "minecraft:item/generated", "textures": {"layer0": f"{MOD}:item/{name}"}})

def tex_image(path, fn):
    img, _ = px(path)
    for x in range(16):
        for y in range(16):
            img.putpixel((x, y), fn(x, y))
    img.save(path)

WHITE, BLACK = (255,255,255,255), (25,25,30,255)
M_, MD_, DK_ = (170,175,182,255), (105,110,118,255), (30,30,36,255)
RD_, TAN, GD, GD2 = (200,30,30,255), (200,150,90,255), (240,200,50,255), (190,140,20,255)

# ------------------------------------------------------------------ characters: icons, plush, recipes, lang
lang = {"itemGroup.fazbear": "Fazbear Animatronics", "itemGroup.fazbear.suits": "Fazbear Suits & Plushies",
        "entity.fazbear.animatronic": "Animatronic"}

HEAD_ICON = {
    "bear_ears": lambda b,a,k: [(2,3,4,5,b),(11,3,13,5,b)], "bear_ears_big": lambda b,a,k: [(1,2,4,5,b),(11,2,14,5,b)],
    "bear_ear_left_only": lambda b,a,k: [(2,3,4,5,b)], "rabbit_ears": lambda b,a,k: [(4,0,5,4,b),(10,0,11,4,b)],
    "rabbit_one": lambda b,a,k: [(4,0,5,4,b)], "lop_ears": lambda b,a,k: [(1,6,3,12,b),(12,6,14,12,b)],
    "fox_ears": lambda b,a,k: [(3,1,5,4,b),(10,1,12,4,b)], "fox_ear_one": lambda b,a,k: [(3,1,5,4,b)],
    "top_hat": lambda b,a,k: [(4,1,11,3,BLACK)], "top_hat_acc": lambda b,a,k: [(4,1,11,3,a)],
    "cap": lambda b,a,k: [(3,2,12,3,a),(3,4,7,4,BLACK)], "propeller": lambda b,a,k: [(7,0,8,2,a)],
    "beak": lambda b,a,k: [(6,10,9,12,a)], "beak_open": lambda b,a,k: [(6,9,9,10,a),(6,12,9,13,a)],
    "fox_snout": lambda b,a,k: [(5,10,10,12,shade(b,0.8))], "wolf_snout": lambda b,a,k: [(5,10,10,12,shade(b,0.8))],
    "gator_snout": lambda b,a,k: [(4,10,11,13,shade(b,0.8)),(4,11,11,11,WHITE)],
    "tuft": lambda b,a,k: [(7,2,8,3,b)], "eyepatch": lambda b,a,k: [(4,6,6,9,BLACK)],
    "cheeks": lambda b,a,k: [(3,10,4,11,a),(11,10,12,11,a)], "cheeks_det": lambda b,a,k: [(3,10,4,11,RD_),(11,10,12,11,RD_)],
    "pigtails": lambda b,a,k: [(0,6,2,12,a),(13,6,15,12,a)], "jaw_teeth": lambda b,a,k: [(5,12,10,12,WHITE)],
    "horns": lambda b,a,k: [(4,1,5,4,a),(10,1,11,4,a)], "rays": lambda b,a,k: [(7,0,8,3,a),(1,5,2,7,a),(13,5,14,7,a)],
    "headphones": lambda b,a,k: [(2,6,3,11,a),(12,6,13,11,a),(3,3,12,3,a)], "bun": lambda b,a,k: [(6,1,9,3,a)],
    "mask_band": lambda b,a,k: [(4,6,11,8,a)], "wires": lambda b,a,k: [(2,2,3,10,a),(12,2,13,10,a),(7,1,8,3,a)],
    "shades": lambda b,a,k: [(4,7,11,9,a)], "lashes": lambda b,a,k: [(4,6,6,6,BLACK),(9,6,11,6,BLACK)],
    "exposed_jaw": lambda b,a,k: [(5,12,10,13,M_)], "torn_face": lambda b,a,k: [(7,6,9,9,M_)],
    "tears": lambda b,a,k: [(5,10,5,12,BLACK),(10,10,10,12,BLACK)],
}

def char_icons(c):
    key = c["key"]
    body, acc, belly, eye = rgb(c["tex"][0]), rgb(c["tex"][1]), rgb(c["tex"][2]), rgb(c["tex"][3])
    base = acc if c["hb"] == "mask" else body
    head = [(3,4,12,13,base),(4,7,6,9,eye),(9,7,11,9,eye),(5,8,5,8,BLACK),(10,8,10,8,BLACK),(5,11,10,11,BLACK)]
    for f in c["head_feats"]:
        if f in HEAD_ICON: head += HEAD_ICON[f](body, acc, belly)
    icon(f"suit_head_{key}", head)
    torso = [(3,2,12,13,body),(5,4,10,11,belly)]
    if any(f.startswith("bow") for f in c["torso_feats"]): torso.append((6,2,9,3,BLACK if "bow_dark" in c["torso_feats"] else acc))
    if "dress" in c["torso_feats"] or "skirt" in c["torso_feats"]: torso.append((2,9,13,13,acc))
    if "torn_chest" in c["torso_feats"] or "ribs" in c["torso_feats"]: torso.append((6,5,9,10,M_))
    icon(f"suit_torso_{key}", torso)
    arms = [(2,2,5,12,body),(10,2,13,12,body),(1,12,6,14,belly),(9,12,14,14,belly)]
    if "hook" in c["arms_feats"]: arms.append((11,12,12,15,M_))
    if "claws" in c["arms_feats"]: arms += [(1,14,1,15,WHITE),(3,14,3,15,WHITE),(10,14,10,15,WHITE),(12,14,12,15,WHITE)]
    icon(f"suit_arms_{key}", arms)
    legs = [(3,1,6,11,body),(9,1,12,11,body),(2,11,7,13,acc),(8,11,13,13,acc)]
    icon(f"suit_legs_{key}", legs)
    icon(f"suit_full_{key}", [(5,0,10,4,base),(6,2,6,2,eye),(9,2,9,2,eye),(4,5,11,10,body),(1,5,3,10,body),(12,5,14,10,body),
                              (5,11,6,15,body),(9,11,10,15,body),(6,6,9,8,belly)])

def plush(c):
    key = c["key"]
    s = 0.7
    elems = [box([4.5,0,5],[11.5,7,11],"t0"), box([5.5,0.5,4.6],[10.5,5.5,5],"t2"),
             box([3,1,6],[4.5,5,10],"t0"), box([11.5,1,6],[13,5,10],"t0")]
    for (x1,y1,z1,x2,y2,z2,t,side) in c["slots"][0]:
        f = [8+(x1-8)*s, 7+(y1-24)*s, 8+(z1-8)*s]
        t2 = [8+(x2-8)*s, 7+(y2-24)*s, 8+(z2-8)*s]
        elems.append(box([round(v,3) for v in f], [round(v,3) for v in t2], f"t{t}"))
    tex = {f"t{i}": mc(n) for i, n in enumerate(c["tex"])}
    tex["particle"] = mc(c["tex"][0])
    n = f"plush_{key}"
    w(f"{A}/models/block/{n}.json", {"textures": tex, "elements": elems})
    w(f"{A}/blockstates/{n}.json", {"variants": {f"facing={fc}": {"model": f"{MOD}:block/{n}", "y": r} for fc, r in ROT}})
    item_model_block(n, n)
    loot(n)

# recipe ingredient pairs: unique (wool, binder) per character
BINDERS = ["minecraft:leather", "minecraft:iron_ingot", "minecraft:gold_ingot", "minecraft:copper_ingot",
           "minecraft:amethyst_shard", "minecraft:lapis_lazuli", "minecraft:redstone", "minecraft:glowstone_dust",
           "minecraft:quartz", "minecraft:string"]
FIXED = {"golden_freddy": "minecraft:gold_ingot"}
used = set()
for c in CHARS:
    wool = f"minecraft:{c['wool']}"
    if c["key"] in FIXED: bind = FIXED[c["key"]]
    else:
        bind = next(b for b in BINDERS if (wool, b) not in used)
    used.add((wool, bind))
    c["wool_item"], c["bind_item"] = wool, bind

def ing(v):
    return {"item": v}

def shaped(name, pattern, key, result, count=1):
    w(f"{D}/recipes/{name}.json", {"type": "minecraft:crafting_shaped", "pattern": pattern,
        "key": {k: ing(v) for k, v in key.items()}, "result": {"item": f"{MOD}:{result}", "count": count}})

def shapeless(name, items, result, count=1):
    w(f"{D}/recipes/{name}.json", {"type": "minecraft:crafting_shapeless",
        "ingredients": [ing(i) for i in items], "result": {"item": f"{MOD}:{result}", "count": count}})

SLOTS = ["head", "torso", "arms", "legs"]
SLOT_NAMES = ["Head", "Torso", "Arms", "Legs"]
for c in CHARS:
    k = c["key"]
    char_icons(c)
    plush(c)
    key = {"W": c["wool_item"], "L": c["bind_item"]}
    shaped(f"suit_head_{k}",  ["WWW", "WLW"], key, f"suit_head_{k}")
    shaped(f"suit_torso_{k}", ["WLW", "WWW", "WWW"], key, f"suit_torso_{k}")
    shaped(f"suit_arms_{k}",  ["WWL", "WWL"], key, f"suit_arms_{k}")
    shaped(f"suit_legs_{k}",  ["WLW", "W W", "W W"], key, f"suit_legs_{k}")
    shapeless(f"suit_full_{k}", [f"{MOD}:suit_{s}_{k}" for s in SLOTS], f"suit_full_{k}")
    shapeless(f"plush_{k}", [f"{MOD}:suit_head_{k}", c["wool_item"], "minecraft:string"], f"plush_{k}")
    lang[f"block.fazbear.plush_{k}"] = f"{c['name']} Plushie"
    lang[f"item.fazbear.suit_full_{k}"] = f"{c['name']} Full Suit"
    for i, s in enumerate(SLOTS):
        lang[f"item.fazbear.suit_{s}_{k}"] = f"{c['name']} Suit {SLOT_NAMES[i]}"

# ------------------------------------------------------------------ endo types
KINDS = ["leg", "torso", "arm", "head"]
KIND_NAMES = ["Leg", "Torso", "Arm", "Head"]
for e in ENDOS:
    col = (e["rgb"][0], e["rgb"][1], e["rgb"][2], 255)
    dk = shade(col, 0.55)
    ev = (120, 255, 120, 255) if e["key"] == "02" else WHITE
    icon(f"endo_{e['key']}_leg",   [(6,1,9,11,col),(6,5,9,6,dk),(4,11,10,13,col),(6,1,9,1,dk)])
    icon(f"endo_{e['key']}_arm",   [(6,1,9,12,col),(6,6,9,7,dk),(5,12,10,14,col)])
    icon(f"endo_{e['key']}_torso", [(3,2,12,13,col),(3,2,12,2,dk),(6,5,9,10,DK_),(7,6,8,9,RD_)])
    icon(f"endo_{e['key']}_head",  [(3,3,12,12,col),(4,6,6,8,ev),(9,6,11,8,ev),(5,7,5,7,DK_),(10,7,10,7,DK_),(5,10,10,11,DK_)])
    main = e["main"]
    p = "minecraft:piston"
    shaped(f"endo_{e['key']}_leg",   ["M ", "P ", "MM"], {"M": main, "P": p}, f"endo_{e['key']}_leg")
    shaped(f"endo_{e['key']}_arm",   ["MM", "P ", "M "], {"M": main, "P": p}, f"endo_{e['key']}_arm")
    shaped(f"endo_{e['key']}_torso", ["MMM", "MRM", "MMM"], {"M": main, "R": "minecraft:redstone_block"}, f"endo_{e['key']}_torso")
    shaped(f"endo_{e['key']}_head",  ["MMM", "MLM", "MMM"], {"M": main, "L": "minecraft:redstone_lamp"}, f"endo_{e['key']}_head")
    for kind, kn in zip(KINDS, KIND_NAMES):
        lang[f"item.fazbear.endo_{e['key']}_{kind}"] = f"{e['name']} {kn}"

# ------------------------------------------------------------------ simple blocks + generated block textures
for b in ("checker_tile", "party_wall", "show_stage"):
    w(f"{A}/blockstates/{b}.json", {"variants": {"": {"model": f"{MOD}:block/{b}"}}})
    w(f"{A}/models/block/{b}.json", {"parent": "minecraft:block/cube_all", "textures": {"all": f"{MOD}:block/{b}"}})
    item_model_block(b, b)
    loot(b)
tex_image(f"{A}/textures/block/checker_tile.png", lambda x, y: (20,20,22,255) if (x//8 + y//8) % 2 == 0 else (235,235,235,255))
tex_image(f"{A}/textures/block/party_wall.png", lambda x, y: (240,240,240,255) if x % 8 in (0,1) else ((90,40,140,255) if (x+y) % 8 else (110,60,160,255)))
tex_image(f"{A}/textures/block/show_stage.png", lambda x, y: (225,180,45,255) if x in (0,15) or y in (0,15) else ((75,42,26,255) if (x+y) % 4 else (88,52,32,255)))
rnd = random.Random(7)
tex_image(f"{A}/textures/block/monitor_screen.png",
          lambda x, y: (lambda v: (v, min(255, v + 10), v, 255))(max(30, min(245, rnd.randint(60, 200) - (40 if y % 3 == 0 else 0)))))
tex_image(f"{A}/textures/block/arcade_screen.png",
          lambda x, y: [(20,20,60,255),(255,60,60,255),(60,220,255,255),(255,230,60,255)][(x // 3 + y // 2) % 4] if (x * y) % 5 else (10,10,30,255))
rnd2 = random.Random(3)
tex_image(f"{A}/textures/block/pirate_curtain.png",
          lambda x, y: (255,225,90,255) if rnd2.random() < 0.06 else ((95,40,125,255) if x % 4 else (75,30,105,255)))

# endo stand (drawn by the block entity renderer)
w(f"{A}/blockstates/endo_stand.json", {"multipart": [{"apply": {"model": f"{MOD}:block/endo_stand"}}]})
w(f"{A}/models/block/endo_stand.json", {"textures": {"particle": mc("iron_block")}, "elements": []})
icon("endo_stand", [(2,13,13,14,DK_),(6,2,9,12,M_),(4,5,11,6,M_),(5,2,10,3,M_)])

# ------------------------------------------------------------------ decor blocks
def facing_bs(n, model=None):
    w(f"{A}/blockstates/{n}.json", {"variants": {f"facing={fc}": {"model": f"{MOD}:block/{model or n}", "y": r} for fc, r in ROT}})

def decor(n, boxes, tex, particle):
    t = dict(tex); t["particle"] = particle
    w(f"{A}/models/block/{n}.json", {"textures": t, "elements": [box(f, to, k) for f, to, k in boxes]})
    item_model_block(n, n)
    loot(n)

facing_bs("arcade_cabinet")
decor("arcade_cabinet",
      [([2,0,3],[14,8,13],"body"), ([3,8,6],[13,14,13],"body"), ([4,9,5.6],[12,13.5,6],"screen"),
       ([2,7.5,2],[14,8.5,6],"panel"), ([4,8.5,3],[5.5,9.5,4.5],"red"), ([7,8.5,3],[8.5,9.5,4.5],"yel"),
       ([10,8.5,3],[11.5,9.5,4.5],"red"), ([3,14,6],[13,16,13],"marq")],
      {"body": mc("blue_concrete"), "screen": f"{MOD}:block/arcade_screen", "panel": mc("black_concrete"),
       "red": mc("red_concrete"), "yel": mc("yellow_concrete"), "marq": mc("magenta_concrete")}, mc("blue_concrete"))
facing_bs("prize_counter")
decor("prize_counter",
      [([0,0,2],[16,10,14],"wood"), ([0,10,2],[16,11,14],"top"), ([1,11,5],[4,14,8],"p1"),
       ([6,11,5],[9,14,8],"p2"), ([11,11,5],[14,14,8],"p3"), ([0,11,12],[16,16,14],"sign")],
      {"wood": mc("dark_oak_planks"), "top": mc("quartz_block_top"), "p1": mc("red_wool"),
       "p2": mc("light_blue_wool"), "p3": mc("yellow_wool"), "sign": mc("gold_block")}, mc("dark_oak_planks"))
facing_bs("party_table")
decor("party_table",
      [([6,0,6],[10,10,10],"leg"), ([0,10,0],[16,12,16],"cloth"), ([6,12,6],[10,13,10],"hat"),
       ([7,13,7],[9,15,9],"hat"), ([7.5,15,7.5],[8.5,16,8.5],"pom")],
      {"leg": mc("spruce_planks"), "cloth": mc("white_wool"), "hat": mc("purple_wool"), "pom": mc("yellow_wool")}, mc("white_wool"))
facing_bs("security_monitor")
decor("security_monitor",
      [([3,0,3],[13,2,13],"dark"), ([7,2,7],[9,5,9],"dark"), ([2,5,6],[14,14,10],"dark"), ([3,6,5.7],[13,13,6],"screen")],
      {"dark": mc("black_concrete"), "screen": f"{MOD}:block/monitor_screen"}, mc("black_concrete"))
w(f"{A}/blockstates/music_box.json", {"multipart": [
    {"when": {"facing": fc}, "apply": {"model": f"{MOD}:block/music_box", "y": r}} for fc, r in ROT]})
decor("music_box",
      [([3,0,4],[13,6,12],"wood"), ([3,6,4],[13,7,12],"gold"), ([7,7,7],[9,9,9],"pink"),
       ([13,2,7.5],[15,3,8.5],"metal"), ([15,1.5,7],[16,3.5,9],"gold")],
      {"wood": mc("dark_oak_planks"), "gold": mc("gold_block"), "pink": mc("pink_wool"), "metal": mc("iron_block")}, mc("dark_oak_planks"))

# power core: 5 charge levels shown on the beacon on top
LEVEL_TEX = ["black_concrete", "red_concrete", "orange_concrete", "yellow_concrete", "lime_concrete"]
for lv in range(5):
    t = {"metal": mc("iron_block"), "dark": mc("black_concrete"), "beacon": mc(LEVEL_TEX[lv]), "particle": mc("iron_block")}
    els = [box([1,0,1],[15,14,15],"metal"), box([6,14,6],[10,16,10],"beacon"),
           box([3,3,0.6],[13,11,1],"dark"), box([3,3,15],[13,11,15.4],"dark"),
           box([0.6,3,3],[1,11,13],"dark"), box([15,3,3],[15.4,11,13],"dark")]
    for i in range(lv):
        y = 4 + i * 1.6
        els.append(box([4,y,0.5],[12,y + 1,0.7],"beacon"))
    w(f"{A}/models/block/power_core_{lv}.json", {"textures": t, "elements": els})
w(f"{A}/blockstates/power_core.json", {"variants": {f"level={lv}": {"model": f"{MOD}:block/power_core_{lv}"} for lv in range(5)}})
item_model_block("power_core", "power_core_4")
loot("power_core")

# plate blocks: security door + pirate cove curtain (north/south share a model, east/west rotate it)
def plate_bs(n):
    v = {}
    for fc, r in ROT:
        for op in ("false", "true"):
            v[f"facing={fc},open={op}"] = {"model": f"{MOD}:block/{n}_{'open' if op == 'true' else 'closed'}", "y": r % 180}
    w(f"{A}/blockstates/{n}.json", {"variants": v})

plate_bs("security_door")
td = {"iron": mc("iron_block"), "dark": mc("black_concrete"), "win": mc("light_gray_concrete"), "particle": mc("iron_block")}
w(f"{A}/models/block/security_door_closed.json", {"textures": td, "elements": [
    box([0,0,6],[16,16,10],"iron"), box([0,0,5.8],[16,2,10.2],"dark"), box([0,14,5.8],[16,16,10.2],"dark"),
    box([4,6,5.7],[12,11,10.3],"win")]})
w(f"{A}/models/block/security_door_open.json", {"textures": td, "elements": [
    box([0,0,6],[2,16,10],"iron"), box([14,0,6],[16,16,10],"iron"), box([0,14,5.8],[16,16,10.2],"dark")]})
item_model_block("security_door", "security_door_closed")
loot("security_door")

plate_bs("pirate_cove_curtain")
tc = {"cur": f"{MOD}:block/pirate_curtain", "dark": mc("black_concrete"), "particle": f"{MOD}:block/pirate_curtain"}
w(f"{A}/models/block/pirate_cove_curtain_closed.json", {"textures": tc, "elements": [
    box([0,0,7],[16,16,9],"cur"), box([0,15,6],[16,16,10],"dark")]})
w(f"{A}/models/block/pirate_cove_curtain_open.json", {"textures": tc, "elements": [
    box([0,0,6.5],[3,16,9.5],"cur"), box([13,0,6.5],[16,16,9.5],"cur"), box([0,15,6],[16,16,10],"dark")]})
item_model_block("pirate_cove_curtain", "pirate_cove_curtain_closed")
loot("pirate_cove_curtain")

# ceiling light
tl = lambda lit: {"frame": mc("iron_block"), "panel": mc("sea_lantern" if lit else "gray_concrete"), "particle": mc("iron_block")}
for lit in (False, True):
    w(f"{A}/models/block/faz_light_{'on' if lit else 'off'}.json", {"textures": tl(lit), "elements": [
        box([0,15,0],[16,16,16],"frame"), box([1,13,1],[15,15,15],"panel")]})
w(f"{A}/blockstates/faz_light.json", {"variants": {"lit=false": {"model": f"{MOD}:block/faz_light_off"},
                                                  "lit=true": {"model": f"{MOD}:block/faz_light_on"}}})
item_model_block("faz_light", "faz_light_on")
loot("faz_light")

# light switch (lever tilts when ON)
for on in (False, True):
    ang = 22.5 if on else -22.5
    t = {"dark": mc("black_concrete"), "ind": mc("lime_concrete" if on else "red_concrete"),
         "metal": mc("iron_block"), "knob": mc("red_concrete"), "particle": mc("black_concrete")}
    rot = {"angle": ang, "axis": "x", "origin": [8, 6, 8]}
    w(f"{A}/models/block/light_switch_{'on' if on else 'off'}.json", {"textures": t, "elements": [
        box([4,0,5],[12,6,11],"dark"), box([5,6,6],[7,7,7],"ind"),
        box([7.5,6,7.5],[8.5,10,8.5],"metal", rot), box([7,10,7],[9,11.5,9],"knob", rot)]})
v = {}
for fc, r in ROT:
    for on in ("false", "true"):
        v[f"facing={fc},on={on}"] = {"model": f"{MOD}:block/light_switch_{'on' if on == 'true' else 'off'}", "y": r}
w(f"{A}/blockstates/light_switch.json", {"variants": v})
item_model_block("light_switch", "light_switch_off")
loot("light_switch")

# ------------------------------------------------------------------ item icons
icon("service_wrench", [(3,2,5,4,M_),(9,2,11,4,M_),(3,4,11,5,M_),(6,5,8,14,MD_),(5,13,9,14,DK_)])
icon("pizza", [(2,3,13,13,(230,180,90,255)),(3,4,12,12,(200,50,40,255)),(4,5,6,7,(250,220,110,255)),
               (9,6,11,8,(250,220,110,255)),(6,9,8,11,(250,220,110,255)),(10,10,11,11,(40,140,40,255))])
icon("pizzeria_blueprint", [(1,1,14,14,(40,90,200,255)),(3,3,12,3,WHITE),(3,6,12,6,WHITE),(3,9,9,9,WHITE),(3,12,11,12,WHITE)])
icon("faz_token", [(4,4,11,11,GD),(5,5,10,10,GD2),(7,6,8,9,GD),(6,6,9,6,GD)])
icon("faz_key", [(2,2,6,6,GD),(4,4,4,4,(0,0,0,0)),(6,5,13,6,GD),(11,7,12,9,GD),(8,7,9,8,GD)])
icon("flashlight", [(2,5,6,10,M_),(6,4,13,11,MD_),(13,3,14,12,(255,240,150,255)),(7,6,12,9,DK_),(3,6,5,9,RD_)])

# ------------------------------------------------------------------ other recipes
IRON = "minecraft:iron_ingot"
shaped("endo_stand", [" I ", "III", "SSS"], {"I": IRON, "S": "minecraft:stone"}, "endo_stand")
shaped("service_wrench", ["I I", " I ", " S "], {"I": IRON, "S": "minecraft:stick"}, "service_wrench")
shapeless("pizza", ["minecraft:bread", "minecraft:bread", "minecraft:cooked_porkchop", "minecraft:beetroot"], "pizza", 2)
shaped("pizzeria_blueprint", ["PPP", "PGP", "PPP"], {"P": "minecraft:paper", "G": "minecraft:gold_ingot"}, "pizzeria_blueprint")
shaped("checker_tile", ["BW", "WB"], {"B": "minecraft:black_concrete", "W": "minecraft:white_concrete"}, "checker_tile", 4)
shaped("party_wall", ["PW", "WP"], {"P": "minecraft:purple_concrete", "W": "minecraft:white_concrete"}, "party_wall", 4)
shaped("show_stage", ["DDD", "GGG"], {"D": "minecraft:dark_oak_planks", "G": "minecraft:gold_nugget"}, "show_stage", 3)
shaped("arcade_cabinet", ["BBB", "BGB", "BRB"], {"B": "minecraft:blue_concrete", "G": "minecraft:glass_pane", "R": "minecraft:redstone"}, "arcade_cabinet")
shaped("prize_counter", ["QQQ", "PPP", "PPP"], {"Q": "minecraft:quartz", "P": "minecraft:dark_oak_planks"}, "prize_counter")
shaped("party_table", ["WWW", " F "], {"W": "minecraft:white_wool", "F": "minecraft:spruce_fence"}, "party_table")
shaped("security_monitor", ["III", "IGI", " R "], {"I": IRON, "G": "minecraft:glass_pane", "R": "minecraft:redstone"}, "security_monitor")
shaped("music_box", ["GGG", "PNP", "PPP"], {"G": "minecraft:gold_ingot", "N": "minecraft:note_block", "P": "minecraft:dark_oak_planks"}, "music_box")
shaped("flashlight", ["G", "R", "I"], {"G": "minecraft:glowstone_dust", "R": "minecraft:redstone", "I": IRON}, "flashlight")
shaped("faz_key", ["GG", "GI", " I"], {"G": "minecraft:gold_ingot", "I": IRON}, "faz_key")
shapeless("faz_token", ["minecraft:gold_nugget"] * 3, "faz_token")
shaped("power_core", ["III", "IBI", "III"], {"I": IRON, "B": "minecraft:redstone_block"}, "power_core")
shaped("security_door", ["II", "II", "II"], {"I": IRON}, "security_door", 2)
shaped("pirate_cove_curtain", ["WW", "WW", "WW"], {"W": "minecraft:purple_wool"}, "pirate_cove_curtain", 3)
shaped("faz_light", ["III", "ILI"], {"I": IRON, "L": "minecraft:redstone_lamp"}, "faz_light", 2)
shaped("light_switch", [" L ", "IRI"], {"L": "minecraft:lever", "I": IRON, "R": "minecraft:redstone"}, "light_switch")

# ------------------------------------------------------------------ advancements
ADV = {}
def adv(name, icon_item, title, desc, parent=None, items=None, frame="task"):
    d = {"display": {"icon": {"item": f"{MOD}:{icon_item}"},
                     "title": {"translate": f"advancement.{MOD}.{name}.title"},
                     "description": {"translate": f"advancement.{MOD}.{name}.desc"},
                     "frame": frame, "show_toast": True, "announce_to_chat": True, "hidden": False}}
    if parent:
        d["parent"] = f"{MOD}:{parent}"
        d["criteria"] = {"got": {"trigger": "minecraft:inventory_changed",
                                 "conditions": {"items": [{"items": [f"{MOD}:{i}" for i in items]}]}}}
    else:
        d["display"]["background"] = "minecraft:textures/gui/advancements/backgrounds/stone.png"
        d["criteria"] = {"tick": {"trigger": "minecraft:tick"}}
    d["requirements"] = [[list(d["criteria"].keys())[0]]]
    w(f"{D}/advancements/{name}.json", d)
    ADV[f"advancement.{MOD}.{name}.title"] = title
    ADV[f"advancement.{MOD}.{name}.desc"] = desc

all_endo = [f"endo_{e['key']}_{k}" for e in ENDOS for k in KINDS]
adv("root", "endo_01_head", "Fazbear Animatronics", "Welcome to the pizzeria.")
adv("first_part", "endo_01_head", "Some Assembly Required", "Craft an endoskeleton part.", "root", all_endo)
adv("suit_up", "suit_full_freddy", "Fresh Suit", "Craft a full animatronic suit.", "first_part", [f"suit_full_{c['key']}" for c in CHARS])
adv("wake_up", "faz_key", "It's Alive", "Craft a Faz Key to wake an animatronic.", "suit_up", ["faz_key"])
adv("night_guard", "flashlight", "Night Guard", "Craft a flashlight.", "wake_up", ["flashlight"], "goal")
adv("power_station", "power_core", "Power Station", "Craft a Power Core.", "night_guard", ["power_core"])
adv("wired_up", "light_switch", "Wired Up", "Craft a light switch. Link lights and doors to it with the Service Wrench.", "power_station", ["light_switch"])
adv("lullaby", "music_box", "Keep It Wound", "Craft a music box.", "night_guard", ["music_box"], "challenge")
adv("prize_winner", "faz_token", "Prize Winner", "Get a Faz Token from an arcade cabinet.", "root", ["faz_token"])
adv("pizza_party", "pizza", "Pizza Party", "Make a pizza.", "root", ["pizza"])

# ------------------------------------------------------------------ lang
lang.update(ADV)
lang.update({
    "block.fazbear.endo_stand": "Endo Stand", "block.fazbear.checker_tile": "Checkered Tile",
    "block.fazbear.party_wall": "Party Wall", "block.fazbear.show_stage": "Show Stage",
    "block.fazbear.arcade_cabinet": "Arcade Cabinet", "block.fazbear.prize_counter": "Prize Counter",
    "block.fazbear.party_table": "Party Table", "block.fazbear.security_monitor": "Security Monitor",
    "block.fazbear.music_box": "Music Box", "block.fazbear.power_core": "Power Core",
    "block.fazbear.security_door": "Security Door", "block.fazbear.pirate_cove_curtain": "Pirate Cove Curtain",
    "block.fazbear.faz_light": "Office Light", "block.fazbear.light_switch": "Light Switch",
    "item.fazbear.service_wrench": "Service Wrench", "item.fazbear.pizza": "Pizza",
    "item.fazbear.pizzeria_blueprint": "Pizzeria Blueprint", "item.fazbear.faz_token": "Faz Token",
    "item.fazbear.faz_key": "Faz Key", "item.fazbear.flashlight": "Flashlight",
})
w(f"{A}/lang/en_us.json", lang)
w(f"{RES}/pack.mcmeta", {"pack": {"description": "Fazbear Animatronics resources", "pack_format": 15}})
print(f"generated {len(CHARS)} characters, {len(ENDOS)} endo types")
